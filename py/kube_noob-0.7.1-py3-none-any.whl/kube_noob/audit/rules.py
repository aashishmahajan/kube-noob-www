"""Deterministic rule set.

Each rule has stable metadata (id, title, stage, default severity, remediation, citations) and a check function
``check(ctx) -> Iterable[Finding]``. Rule ids are part of the public contract (graders, exercises and the training
reward refer to them), so never renumber; retire with ``deprecated=True`` instead.
"""

from __future__ import annotations

import math
import re
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field
from typing import Any

from kube_noob.audit.controls import controls_for
from kube_noob.audit.model import Finding, Severity, Stage
from kube_noob.audit.podspec import (
    LONG_RUNNING_KINDS,
    REPLICATED_KINDS,
    ContainerRef,
    PodTemplate,
    containers,
    effective_security,
    pdb_allows_no_disruption,
    pod_template,
    replicas,
    selector_matches,
)
from kube_noob.audit.quantity import parse_quantity
from kube_noob.catalog import (
    ADDON_GROUPS_ON_VANILLA,
    KIND_API_VERSIONS,
    KNOWN_STORAGE_CLASSES,
    OPENSHIFT_FAMILY,
    OPENSHIFT_ONLY_GROUPS,
    PROVISIONERS,
    ROSA_FAMILY,
    api_group,
    deprecated_api,
    parse_minor,
    removed_api,
)
from kube_noob.yamlio import Document, PathT, fmt_path, get_path


@dataclass
class AuditContext:
    docs: list[Document]
    platform: str
    k8s_version: str
    platform_version: str | None = None

    @property
    def is_openshift(self) -> bool:
        return self.platform in OPENSHIFT_FAMILY

    @property
    def is_rosa(self) -> bool:
        return self.platform in ROSA_FAMILY

    def by_kind(self, *kinds: str) -> list[Document]:
        return [d for d in self.docs if d.kind in kinds]

    def workloads(self) -> Iterator[tuple[Document, PodTemplate]]:
        for d in self.docs:
            pt = pod_template(d)
            if pt is not None:
                yield d, pt

    def ns(self, doc: Document) -> str:
        return doc.namespace or "<default>"


@dataclass(frozen=True)
class Rule:
    rule_id: str
    title: str
    stage: Stage
    category: str
    severity: Severity
    remediation: str
    description: str
    citations: tuple[str, ...] = ()
    stackrox_policies: tuple[str, ...] = ()
    check: Callable[[AuditContext, Rule], Iterable[Finding]] | None = field(default=None, compare=False)

    def finding(
        self,
        doc: Document | None,
        path: PathT,
        message: str,
        *,
        severity: Severity | None = None,
        remediation: str | None = None,
        resource: str | None = None,
    ) -> Finding:
        return Finding(
            rule_id=self.rule_id,
            title=self.title,
            severity=severity if severity is not None else self.severity,
            stage=self.stage,
            category=self.category,
            resource=resource or (doc.ref() if doc else "<bundle>"),
            message=message,
            remediation=remediation or self.remediation,
            path=fmt_path(path),
            line=doc.line_for(path) if doc else None,
            doc_index=doc.index if doc else None,
            citations=list(self.citations),
            stackrox_policies=list(self.stackrox_policies),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "ruleId": self.rule_id,
            "title": self.title,
            "stage": self.stage.value,
            "category": self.category,
            "defaultSeverity": self.severity.name.lower(),
            "description": self.description,
            "remediation": self.remediation,
            "citations": list(self.citations),
            "stackroxPolicies": list(self.stackrox_policies),
            "controls": controls_for(self.rule_id),
        }


RULES: dict[str, Rule] = {}


def rule(
    rule_id: str,
    title: str,
    stage: Stage,
    category: str,
    severity: Severity,
    remediation: str,
    description: str,
    citations: tuple[str, ...] = (),
    stackrox: tuple[str, ...] = (),
) -> Callable[[Callable[[AuditContext, Rule], Iterable[Finding]]], Callable[[AuditContext, Rule], Iterable[Finding]]]:
    def deco(
        fn: Callable[[AuditContext, Rule], Iterable[Finding]],
    ) -> Callable[[AuditContext, Rule], Iterable[Finding]]:
        if rule_id in RULES:
            raise RuntimeError(f"duplicate rule id {rule_id}")
        RULES[rule_id] = Rule(
            rule_id, title, stage, category, severity, remediation, description, citations, stackrox, fn
        )
        return fn

    return deco


DNS1123_SUBDOMAIN = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*\Z")

# =====================================================================================================
# ingress-nginx (kubernetes/ingress-nginx): CVE signatures and retirement
# =====================================================================================================
# The project is retired: best-effort maintenance ended in March 2026 and the repository was archived on
# 2026-03-24 (ingress-nginx-retired). Every fact below is from the Kubernetes CVE feed issue or the project
# document named in the citation; the fixed versions are the releases those issues name.

INGRESS_NGINX_ANNOTATION_PREFIX = "nginx.ingress.kubernetes.io/"
INGRESS_NGINX_CLASS = "nginx"
# docs/user-guide/nginx-configuration/annotations-risk.md: the annotations rated Critical and High.
INGRESS_NGINX_CRITICAL_ANNOTATIONS = frozenset(
    {"configuration-snippet", "auth-snippet", "modsecurity-snippet", "server-snippet", "stream-snippet"}
)
INGRESS_NGINX_HIGH_ANNOTATIONS = frozenset(
    {
        "server-alias",
        "auth-tls-error-page",
        "auth-tls-match-cn",
        "auth-signin",
        "auth-url",
        "mirror-host",
        "mirror-target",
        "modsecurity-transaction-id",
        "proxy-ssl-name",
        "upstream-hash-by",
    }
)
# Annotation -> the CVEs that used it, with the fix each feed issue names.
INGRESS_NGINX_ANNOTATION_CVES: dict[str, tuple[tuple[str, str], ...]] = {
    "configuration-snippet": (
        ("CVE-2021-25742", "snippets read every Secret in the cluster; keep allow-snippet-annotations false"),
        ("CVE-2023-5043", "configuration injection; mitigated by v1.9.0 with --enable-annotation-validation"),
    ),
    "auth-snippet": (("CVE-2021-25742", "snippets read every Secret in the cluster"),),
    "modsecurity-snippet": (("CVE-2021-25742", "snippets read every Secret in the cluster"),),
    "server-snippet": (("CVE-2021-25742", "snippets read every Secret in the cluster"),),
    "stream-snippet": (("CVE-2021-25742", "snippets read every Secret in the cluster"),),
    "auth-url": (
        ("CVE-2025-24514", "configuration injection, fixed in v1.11.5 and v1.12.1"),
        ("CVE-2026-24513", "validation bypass, fixed in v1.13.7 and v1.14.3"),
    ),
    "auth-tls-match-cn": (("CVE-2025-1097", "configuration injection, fixed in v1.11.5 and v1.12.1"),),
    "mirror-target": (("CVE-2025-1098", "configuration injection, fixed in v1.11.5 and v1.12.1"),),
    "mirror-host": (("CVE-2025-1098", "configuration injection, fixed in v1.11.5 and v1.12.1"),),
    "permanent-redirect": (("CVE-2023-5044", "configuration injection, fixed in v1.9.0"),),
    "auth-proxy-set-headers": (("CVE-2025-15566", "configuration injection, fixed in v1.12.5 and v1.13.1"),),
    "auth-method": (("CVE-2026-1580", "configuration injection, fixed in v1.13.7 and v1.14.3"),),
    "rewrite-target": (("CVE-2026-3288", "configuration injection, fixed in v1.13.8, v1.14.4 and v1.15.0"),),
}
# Every annotation KN-N009 flags (short name, without the prefix); kube_noob.generate.policies puts it into CEL.
INGRESS_NGINX_RISKY_ANNOTATIONS = frozenset(
    INGRESS_NGINX_CRITICAL_ANNOTATIONS | INGRESS_NGINX_HIGH_ANNOTATIONS | set(INGRESS_NGINX_ANNOTATION_CVES)
)
# ConfigMap keys that widen what an Ingress may ask of the controller (configmap.md gives the defaults).
INGRESS_NGINX_CONFIGMAP_KEYS: dict[str, tuple[str, str, str]] = {
    # key: (value that is unsafe, lower-cased; default; what it allows)
    "allow-snippet-annotations": ("true", "false", "snippet annotations"),
    "annotations-risk-level": ("critical", "High", "Critical-risk annotations (the snippets)"),
    "strict-validate-path-type": ("false", "true", "unvalidated spec.rules[].http.paths[].path values"),
}


@dataclass(frozen=True)
class ComponentAdvisory:
    """CVEs of a component with the first fixed release of each affected minor (later minors are fixed too)."""

    cves: tuple[str, ...]
    fixed: tuple[str, ...]
    summary: str
    citations: tuple[str, ...]

    def affects(self, version: tuple[int, int, int]) -> bool:
        fixed = [_semver(f) for f in self.fixed]
        same = [f[2] for f in fixed if f[:2] == version[:2]]
        if same:
            return version[2] < min(same)
        return version[:2] < max(f[:2] for f in fixed)


_SEMVER = re.compile(r"^v?(\d{1,6})\.(\d{1,6})\.(\d{1,6})\Z")
_INGRESS_NGINX_IMAGE = re.compile(r"(?:^|/)ingress-nginx/controller(?:-chroot)?\Z")


def _semver(text: str) -> tuple[int, int, int]:
    m = _SEMVER.match(text.strip())
    if not m:
        raise ValueError(f"not a version: {text!r}")
    return int(m.group(1)), int(m.group(2)), int(m.group(3))


# Oldest first. CVE-2025-1974 (CVSS 9.8, unauthenticated, through the validating admission webhook) is the one that
# makes the finding critical when the webhook is on (--validating-webhook).
INGRESS_NGINX_ADVISORIES: tuple[ComponentAdvisory, ...] = (
    ComponentAdvisory(
        ("CVE-2021-25742",),
        ("0.49.1", "1.0.1"),
        "custom snippets read every Secret in the cluster (also set allow-snippet-annotations to false)",
        ("k8s-cve-2021-25742",),
    ),
    ComponentAdvisory(
        ("CVE-2021-25745", "CVE-2021-25746"),
        ("1.2.0",),
        "a spec.rules[].http.paths[].path that reads the controller's ServiceAccount token, and directive injection "
        "through annotation values",
        ("k8s-cve-2021-25745", "k8s-cve-2021-25746"),
    ),
    ComponentAdvisory(
        ("CVE-2022-4886",),
        ("1.8.0",),
        "path sanitization bypass through spec.rules[].http.paths[].path",
        ("k8s-cve-2022-4886",),
    ),
    ComponentAdvisory(
        ("CVE-2023-5043", "CVE-2023-5044"),
        ("1.9.0",),
        "configuration injection through the configuration-snippet and permanent-redirect annotations",
        ("k8s-cve-2023-5043", "k8s-cve-2023-5044"),
    ),
    ComponentAdvisory(
        ("CVE-2024-7646",),
        ("1.10.4", "1.11.2"),
        "annotation validation bypass by anyone who can create an Ingress",
        ("k8s-cve-2024-7646",),
    ),
    ComponentAdvisory(
        ("CVE-2025-1974", "CVE-2025-24514", "CVE-2025-1097", "CVE-2025-1098", "CVE-2025-24513"),
        ("1.11.5", "1.12.1"),
        "unauthenticated code execution in the controller through the validating admission webhook "
        "(CVE-2025-1974, CVSS 9.8), configuration injection through the auth-url, auth-tls-match-cn, "
        "mirror-target and mirror-host annotations, and auth secret path traversal",
        ("k8s-cve-2025-1974", "k8s-cve-2025-24514", "k8s-cve-2025-1097", "k8s-cve-2025-1098", "k8s-cve-2025-24513"),
    ),
    ComponentAdvisory(
        ("CVE-2025-15566",),
        ("1.12.5", "1.13.1"),
        "configuration injection through the auth-proxy-set-headers annotation",
        ("k8s-cve-2025-15566",),
    ),
    ComponentAdvisory(
        ("CVE-2026-1580", "CVE-2026-24512", "CVE-2026-24513", "CVE-2026-24514"),
        ("1.13.7", "1.14.3"),
        "configuration injection through the auth-method annotation and ImplementationSpecific paths, auth-url "
        "validation bypass, and a denial of service of the validating admission controller",
        ("k8s-cve-2026-1580", "k8s-cve-2026-24512", "k8s-cve-2026-24513", "k8s-cve-2026-24514"),
    ),
    ComponentAdvisory(
        ("CVE-2026-3288",),
        ("1.13.8", "1.14.4", "1.15.0"),
        "configuration injection through the rewrite-target annotation",
        ("k8s-cve-2026-3288",),
    ),
    ComponentAdvisory(
        ("CVE-2026-4342",),
        ("1.13.9", "1.14.5", "1.15.1"),
        "configuration injection through a combination of annotations",
        ("k8s-cve-2026-4342",),
    ),
)
_WEBHOOK_RCE = "CVE-2025-1974"


def ingress_nginx_version(image: str) -> tuple[int, int, int] | None:
    """The release an ingress-nginx controller image reference names, when its tag is a plain vX.Y.Z."""
    ref = image.split("@", 1)[0]
    last = ref.rsplit("/", 1)[-1]
    name, _, tag = last.partition(":")
    repo = ref[: len(ref) - len(last)] + name
    if not _INGRESS_NGINX_IMAGE.search(repo):
        return None
    m = _SEMVER.match(tag)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None


def is_ingress_nginx_image(image: str) -> bool:
    ref = image.split("@", 1)[0]
    last = ref.rsplit("/", 1)[-1]
    return bool(_INGRESS_NGINX_IMAGE.search(ref[: len(ref) - len(last)] + last.partition(":")[0]))


def _lt(n: int) -> str:
    """RE2 for a decimal integer from 0 to ``n - 1`` (no leading zeros)."""
    if not 0 < n < 100:
        raise ValueError(f"patch threshold out of range: {n}")
    if n == 1:
        return "0"
    if n <= 10:
        return f"[0-{n - 1}]"
    tens, ones = divmod(n, 10)
    parts = [r"\d"]
    if tens >= 2:
        parts.append(r"1\d" if tens == 2 else rf"[1-{tens - 1}]\d")
    if ones:
        parts.append(f"{tens}0" if ones == 1 else f"{tens}[0-{ones - 1}]")
    return "(?:" + "|".join(parts) + ")"


def ingress_nginx_vulnerable_tag_regex() -> str:
    """RE2 (no anchors) for every ``X.Y.Z`` an advisory in INGRESS_NGINX_ADVISORIES affects: what KN-S024 flags."""
    fixed = [_semver(f) for a in INGRESS_NGINX_ADVISORIES for f in a.fixed]
    alternatives: list[str] = []
    for major in sorted({f[0] for f in fixed}):
        top = max(f[1] for f in fixed if f[0] == major)
        thresholds: list[float] = []
        for minor in range(top + 1):
            t = 0.0
            for a in INGRESS_NGINX_ADVISORIES:
                own = [_semver(f) for f in a.fixed]
                same = [f[2] for f in own if f[:2] == (major, minor)]
                if same:
                    t = max(t, float(min(same)))
                elif (major, minor) < max(f[:2] for f in own):
                    t = math.inf
            thresholds.append(t)
        whole = 0
        while whole < len(thresholds) and thresholds[whole] == math.inf:
            whole += 1
        if whole == len(thresholds):
            alternatives.append(rf"{major}\.\d+\.\d+")
        elif whole:
            alternatives.append(rf"{major}\.{_lt(whole)}\.\d+")
        for minor in range(whole, len(thresholds)):
            t = thresholds[minor]
            if t == math.inf:
                alternatives.append(rf"{major}\.{minor}\.\d+")
            elif t > 0:
                alternatives.append(rf"{major}\.{minor}\.{_lt(int(t))}")
    return "(?:" + "|".join(alternatives) + ")"


# =====================================================================================================
# VALIDATE
# =====================================================================================================


@rule(
    "KN-V001",
    "Object is missing apiVersion, kind or metadata.name",
    Stage.VALIDATE,
    "schema",
    Severity.HIGH,
    "Every object needs apiVersion, kind and metadata.name (or metadata.generateName).",
    "kubectl/oc reject objects without these identity fields.",
)
def _v001(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        if not isinstance(d.data, dict):
            yield r.finding(
                d, (), "Document is not a mapping; it cannot be a Kubernetes object.", resource=f"doc[{d.index}]"
            )
            continue
        missing = [k for k in ("apiVersion", "kind") if not d.data.get(k)]
        meta = d.data.get("metadata")
        if not isinstance(meta, dict) or not (meta.get("name") or meta.get("generateName")):
            missing.append("metadata.name")
        if missing:
            yield r.finding(d, (), f"Missing required field(s): {', '.join(missing)}.", resource=f"doc[{d.index}]")


@rule(
    "KN-V002",
    "apiVersion does not serve this kind",
    Stage.VALIDATE,
    "api",
    Severity.CRITICAL,
    "Use the apiVersion that serves this kind (see message).",
    "A kind sent to an API group/version that does not serve it fails with 'no matches for kind'. "
    "Classic example: Route is route.openshift.io/v1, not apps.openshift.io/v1 (that group serves DeploymentConfig).",
    ("k8s-deprecation-guide", "ocp-routes"),
)
def _v002(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        if not isinstance(d.data, dict):
            continue
        valid = KIND_API_VERSIONS.get(d.kind)
        if not valid or d.api_version in valid:
            continue
        if removed_api(d.api_version, d.kind, "99.0") is not None:
            continue  # handled by the deprecation rules with a precise version message
        yield r.finding(d, ("apiVersion",), f"{d.kind} is not served by '{d.api_version}'. Use {' or '.join(valid)}.")


@rule(
    "KN-V003",
    "OpenShift-only API used on a non-OpenShift target",
    Stage.VALIDATE,
    "platform",
    Severity.CRITICAL,
    "Target an OpenShift platform, or replace with the upstream equivalent (Route -> Ingress/Gateway API "
    "HTTPRoute, DeploymentConfig -> Deployment, SCC -> Pod Security Admission labels).",
    "Groups such as route.openshift.io or security.openshift.io do not exist on vanilla Kubernetes.",
    ("ocp-routes", "k8s-pss"),
)
def _v003(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    if ctx.is_openshift:
        return
    for d in ctx.docs:
        g = api_group(d.api_version)
        if g in OPENSHIFT_ONLY_GROUPS:
            yield r.finding(
                d,
                ("apiVersion",),
                f"{d.kind} ({d.api_version}) only exists on OpenShift; target platform is '{ctx.platform}'.",
            )


@rule(
    "KN-V004",
    "API requires an add-on on this platform",
    Stage.VALIDATE,
    "platform",
    Severity.MEDIUM,
    "Install the add-on (or its CRDs) before applying, or remove the object.",
    "Some API groups are present by default on OpenShift but need an operator/CRDs on vanilla Kubernetes.",
)
def _v004(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        g = api_group(d.api_version)
        if g in ADDON_GROUPS_ON_VANILLA:
            if ctx.is_openshift and g in {"k8s.ovn.org", "monitoring.coreos.com", "operators.coreos.com"}:
                continue
            # OpenShift 4.19+ ships the standard-channel Gateway API CRDs, managed by the Ingress Operator.
            if (
                ctx.is_openshift
                and g == "gateway.networking.k8s.io"
                and (ctx.platform_version is None or parse_minor(ctx.platform_version) >= (4, 19))
            ):
                continue
            yield r.finding(d, ("apiVersion",), f"{d.kind} needs: {ADDON_GROUPS_ON_VANILLA[g]}.")


@rule(
    "KN-V005",
    "API removed in the target Kubernetes version",
    Stage.VALIDATE,
    "deprecation",
    Severity.CRITICAL,
    "Migrate to the replacement apiVersion (see message); `kube-noob fix` performs mechanical migrations.",
    "Removed APIs are rejected by the API server; the object will not apply.",
    ("k8s-deprecation-guide",),
)
def _v005(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        rem = removed_api(d.api_version, d.kind, ctx.k8s_version)
        if rem:
            repl = f"use {rem.replacement}" if rem.replacement else "no replacement API"
            note = f" Note: {rem.notes}." if rem.notes else ""
            yield r.finding(
                d,
                ("apiVersion",),
                f"{d.kind} {d.api_version} was removed in Kubernetes "
                f"{rem.removed_in} (target {ctx.k8s_version}); {repl}.{note}",
            )


@rule(
    "KN-V006",
    "Deprecated API in the target Kubernetes version",
    Stage.VALIDATE,
    "deprecation",
    Severity.MEDIUM,
    "Migrate before the removal release.",
    "Deprecated APIs still work but will be removed.",
    ("k8s-deprecation-guide",),
)
def _v006(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        dep = deprecated_api(d.api_version, d.kind, ctx.k8s_version)
        if dep:
            yield r.finding(
                d,
                ("apiVersion",),
                f"{d.kind} {d.api_version} is deprecated and is removed in "
                f"Kubernetes {dep.removed_in}; migrate to {dep.replacement or 'a supported API'}.",
            )


@rule(
    "KN-V008",
    "DeploymentConfig is deprecated",
    Stage.VALIDATE,
    "deprecation",
    Severity.MEDIUM,
    "Use apps/v1 Deployment (with image triggers via the image.openshift.io/triggers annotation if needed).",
    "DeploymentConfig (apps.openshift.io/v1) is deprecated since OpenShift 4.14.",
    ("ocp-deploymentconfig-deprecation",),
)
def _v008(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    if not ctx.is_openshift:
        return
    if ctx.platform_version and parse_minor(ctx.platform_version) < (4, 14):
        return
    for d in ctx.by_kind("DeploymentConfig"):
        yield r.finding(
            d, ("kind",), "DeploymentConfig is deprecated (OpenShift 4.14+); new workloads should use Deployment."
        )


@rule(
    "KN-V009",
    "metadata.name is not a valid DNS-1123 name",
    Stage.VALIDATE,
    "schema",
    Severity.HIGH,
    "Use lowercase alphanumerics, '-' and '.', starting and ending with an alphanumeric, max 253 chars "
    "(63 for Services, Namespaces and labels).",
    "The API server rejects invalid object names.",
)
def _v009(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        name = d.name
        if not name:
            continue
        label_only = d.kind in {"Service", "Namespace", "Project"}  # DNS label (Service: DNS-1035, must start a-z)
        limit = 63 if label_only else 253
        if (
            len(name) > limit
            or not DNS1123_SUBDOMAIN.match(name)
            or (label_only and "." in name)
            or (d.kind == "Service" and not name[0].isalpha())
        ):
            yield r.finding(d, ("metadata", "name"), f"'{name}' is not a valid name for {d.kind} (limit {limit}).")


@rule(
    "KN-V010",
    "Workload selector does not match its pod template labels",
    Stage.VALIDATE,
    "schema",
    Severity.CRITICAL,
    "Make spec.selector.matchLabels a subset of spec.template.metadata.labels.",
    "apps/v1 rejects workloads whose selector does not select their own template ('selector does not match "
    "template labels').",
)
def _v010(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        if d.kind not in {"Deployment", "StatefulSet", "DaemonSet", "ReplicaSet"}:
            continue
        sel = get_path(d.data, ("spec", "selector"))
        if not isinstance(sel, dict) or not sel:
            yield r.finding(d, ("spec", "selector"), "spec.selector is required for apps/v1 workloads.")
            continue
        if not selector_matches(sel, pt.labels()):
            yield r.finding(
                d,
                ("spec", "selector"),
                f"Selector {sel.get('matchLabels') or sel} does not match template labels {pt.labels()}.",
            )


@rule(
    "KN-V011",
    "Service selects no pods in this bundle",
    Stage.VALIDATE,
    "wiring",
    Severity.MEDIUM,
    "Align Service spec.selector with the pod template labels of the workload it fronts.",
    "A Service whose selector matches no pods has no endpoints; Routes/Ingresses in front of it return 503.",
)
def _v011(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    workloads = list(ctx.workloads())
    if not workloads:
        return
    for svc in ctx.by_kind("Service"):
        sel = get_path(svc.data, ("spec", "selector"))
        if not isinstance(sel, dict) or not sel:
            continue  # headless/external services without selectors are legitimate
        ns = ctx.ns(svc)
        same_ns = [pt for d, pt in workloads if ctx.ns(d) == ns]
        if not same_ns:
            continue
        if not any(selector_matches({"matchLabels": sel}, pt.labels()) for pt in same_ns):
            yield r.finding(
                svc,
                ("spec", "selector"),
                f"Selector {sel} matches no pod template in namespace {ns}; the Service will have no endpoints.",
            )


@rule(
    "KN-V012",
    "Service targetPort name is not declared by the selected containers",
    Stage.VALIDATE,
    "wiring",
    Severity.HIGH,
    "Declare the named containerPort or use the numeric port.",
    "A named targetPort that no selected container exposes results in a Service without ready endpoints.",
)
def _v012(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    workloads = list(ctx.workloads())
    for svc in ctx.by_kind("Service"):
        sel = get_path(svc.data, ("spec", "selector"))
        if not isinstance(sel, dict) or not sel:
            continue
        pods = [
            pt
            for d, pt in workloads
            if ctx.ns(d) == ctx.ns(svc) and selector_matches({"matchLabels": sel}, pt.labels())
        ]
        if not pods:
            continue
        names = {
            str(p.get("name"))
            for pt in pods
            for c in containers(pt, include_init=False)
            for p in (c.container.get("ports") or [])
            if isinstance(p, dict) and p.get("name")
        }
        for i, port in enumerate(get_path(svc.data, ("spec", "ports")) or []):
            tp = port.get("targetPort") if isinstance(port, dict) else None
            if isinstance(tp, str) and not tp.isdigit() and tp not in names:
                yield r.finding(
                    svc,
                    ("spec", "ports", i, "targetPort"),
                    f"targetPort '{tp}' is not a named "
                    f"containerPort of the selected pods (named ports: {sorted(names) or 'none'}).",
                )


@rule(
    "KN-V014",
    "Duplicate object in bundle",
    Stage.VALIDATE,
    "schema",
    Severity.HIGH,
    "Remove or rename the duplicate; the later object silently overwrites the earlier one on apply.",
    "Two objects with the same kind, namespace and name collide.",
)
def _v014(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    seen: dict[tuple[str, str, str], Document] = {}
    for d in ctx.docs:
        if not d.kind or not d.name:
            continue
        key = (d.kind, d.namespace or "", d.name)
        if key in seen:
            yield r.finding(d, ("metadata", "name"), f"Duplicates doc[{seen[key].index}] ({d.ref()}).")
        else:
            seen[key] = d


@rule(
    "KN-V015",
    "EgressFirewall must be named 'default'",
    Stage.VALIDATE,
    "network",
    Severity.HIGH,
    "Rename the EgressFirewall to 'default' and keep one per namespace.",
    "OVN-Kubernetes accepts a single EgressFirewall per namespace and it must be named 'default'; other names "
    "are rejected/ignored.",
    ("ocp-egressfirewall",),
)
def _v015(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    per_ns: dict[str, int] = {}
    for d in ctx.by_kind("EgressFirewall"):
        per_ns[ctx.ns(d)] = per_ns.get(ctx.ns(d), 0) + 1
        if d.name != "default":
            yield r.finding(d, ("metadata", "name"), f"EgressFirewall is named '{d.name}', must be 'default'.")
    for ns, n in per_ns.items():
        if n > 1:
            yield r.finding(
                None,
                (),
                f"{n} EgressFirewall objects in namespace {ns}; only one is allowed.",
                resource=f"EgressFirewall/{ns}/*",
            )


@rule(
    "KN-V016",
    "Route TLS configuration is invalid",
    Stage.VALIDATE,
    "network",
    Severity.HIGH,
    "termination must be edge, passthrough or reencrypt; passthrough supports insecureEdgeTerminationPolicy "
    "None or Redirect only; certificates are not allowed with passthrough.",
    "The router rejects Routes with invalid TLS settings.",
    ("ocp-routes",),
)
def _v016(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Route"):
        tls = get_path(d.data, ("spec", "tls"))
        if not isinstance(tls, dict):
            continue
        term = tls.get("termination")
        if term not in {"edge", "passthrough", "reencrypt"}:
            yield r.finding(d, ("spec", "tls", "termination"), f"Invalid termination {term!r}.")
            continue
        policy = tls.get("insecureEdgeTerminationPolicy")
        if policy not in {None, "", "None", "Redirect", "Allow"}:
            yield r.finding(d, ("spec", "tls", "insecureEdgeTerminationPolicy"), f"Invalid policy {policy!r}.")
        if term == "passthrough" and policy == "Allow":
            yield r.finding(
                d,
                ("spec", "tls", "insecureEdgeTerminationPolicy"),
                "passthrough Routes cannot use insecureEdgeTerminationPolicy: Allow.",
            )
        if term == "passthrough" and any(tls.get(k) for k in ("certificate", "key", "caCertificate")):
            yield r.finding(
                d, ("spec", "tls"), "passthrough Routes must not carry certificates; the backend terminates TLS."
            )


@rule(
    "KN-V017",
    "MachineConfig is not a customer lever on ROSA",
    Stage.VALIDATE,
    "platform",
    Severity.HIGH,
    "Use the managed interfaces instead: `rosa create kubeletconfig` for kubelet tuning and machine pools "
    "(`rosa create/edit machinepool`) for node sizing, labels and taints.",
    "ROSA is a managed service. On ROSA with HCP the Machine Config Operator does not run in the hosted cluster "
    "(HyperShift applies node configuration from the management side via NodePool config), and Red Hat's guidance "
    "is not to rely on customer-owned MachineConfig changes on ROSA.",
    ("rosa-hcp-architecture",),
)
def _v017(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    if not ctx.is_rosa:
        return
    for d in ctx.by_kind("MachineConfig", "MachineConfigPool"):
        yield r.finding(d, ("kind",), f"{d.kind} is not a supported customer lever on {ctx.platform}.")


@rule(
    "KN-V018",
    "Duplicate key in a YAML mapping",
    Stage.VALIDATE,
    "schema",
    Severity.CRITICAL,
    "Remove the duplicate key and merge its fields into a single mapping.",
    "YAML parsers keep the last value silently, so the object you review is not the one you wrote; kubectl's strict "
    "field validation (the default) rejects duplicate fields outright.",
)
def _v018(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.docs:
        for path, line in d.duplicate_keys:
            f = r.finding(d, path, f"Duplicate key '{fmt_path(path)}' (second occurrence on line {line}).")
            f.line = line
            yield f


_RETIRED = (
    "the kubernetes/ingress-nginx project is retired: best-effort maintenance ended in March 2026, there are no "
    "further releases or bug fixes, and the repository was archived on 2026-03-24."
)


@rule(
    "KN-V019",
    "Ingress targets the retired ingress-nginx",
    Stage.VALIDATE,
    "deprecation",
    Severity.MEDIUM,
    "Move to a Gateway API implementation (Gateway and HTTPRoute; on OpenShift 4.19+ the Ingress Operator manages "
    "Gateway API) or to a maintained ingress controller, and drop the nginx.ingress.kubernetes.io annotations.",
    "ingress-nginx stopped receiving releases and bug fixes when the project was archived on 2026-03-24, so every "
    "later vulnerability stays unfixed; the project itself asks users to identify a Gateway API implementation.",
    ("ingress-nginx-retired",),
)
def _v019(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Ingress"):
        ann = get_path(d.data, ("metadata", "annotations"))
        ann = ann if isinstance(ann, dict) else {}
        nginx = sorted(str(k) for k in ann if str(k).startswith(INGRESS_NGINX_ANNOTATION_PREFIX))
        if nginx:
            more = ", ..." if len(nginx) > 1 else ""
            yield r.finding(
                d,
                ("metadata", "annotations", nginx[0]),
                f"Ingress carries {len(nginx)} ingress-nginx annotation(s) ({nginx[0]}{more}); " + _RETIRED,
            )
            continue
        if str(get_path(d.data, ("spec", "ingressClassName")) or "").strip() == INGRESS_NGINX_CLASS:
            path: PathT = ("spec", "ingressClassName")
        elif str(ann.get("kubernetes.io/ingress.class", "")).strip() == INGRESS_NGINX_CLASS:
            path = ("metadata", "annotations", "kubernetes.io/ingress.class")
        else:
            continue
        yield r.finding(
            d,
            path,
            f"Ingress names the ingress class '{INGRESS_NGINX_CLASS}' (ingress-nginx's class name); if ingress-nginx "
            "serves it, " + _RETIRED,
            severity=Severity.LOW,
        )
    for d, _pt, c in _containers(ctx):
        image = c.container.get("image")
        if isinstance(image, str) and is_ingress_nginx_image(image):
            yield r.finding(
                d,
                (*c.path, "image"),
                f"Container '{c.name}' runs the ingress-nginx controller image '{image}'; " + _RETIRED,
            )


# =====================================================================================================
# AUDIT - security
# =====================================================================================================

DANGEROUS_CAPS = frozenset(
    {
        "ALL",
        "SYS_ADMIN",
        "NET_ADMIN",
        "SYS_PTRACE",
        "SYS_MODULE",
        "DAC_READ_SEARCH",
        "NET_RAW",
        "SYS_RAWIO",
        "SYS_BOOT",
        "MAC_ADMIN",
        "MAC_OVERRIDE",
        "BPF",
        "PERFMON",
        "SYS_CHROOT",
        "SETFCAP",
        "SYS_TIME",
        "SYSLOG",
        "DAC_OVERRIDE",
        "LINUX_IMMUTABLE",
    }
)
PSS_RESTRICTED_ALLOWED_ADD = frozenset({"NET_BIND_SERVICE"})
SENSITIVE_ENV = re.compile(
    r"(PASS(WORD|WD)?|SECRET|TOKEN|API[_-]?KEY|PRIVATE[_-]?KEY|CREDENTIAL|ACCESS[_-]?KEY)", re.IGNORECASE
)
RUNTIME_SOCKETS = ("docker.sock", "containerd.sock", "crio.sock", "cri-dockerd.sock")
# --password=x / --token x / password=x style arguments (group 1: dashes, group 3: inline value). CREDENTIAL_FLAG_NAME
# and EMBEDDED_CREDENTIAL are written for RE2 too: kube_noob.generate.policies puts them into admission CEL.
CREDENTIAL_FLAG_NAME = r"[a-z0-9_.-]*(?:password|passwd|pwd|secret|token|api[-_]?key|access[-_]?key|credentials?)"
_SECRET_FLAG = re.compile(r"(?i)^(-{1,2})?(" + CREDENTIAL_FLAG_NAME + r")(?:[=:](.+))?$")
EMBEDDED_CREDENTIAL = (
    r"://[^:/\s@]+:[^@/\s$]+@|-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"
    r"|eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"
)
_EMBEDDED_SECRET = re.compile(EMBEDDED_CREDENTIAL)


def _is_reference(value: str) -> bool:
    v = value.strip()
    return v.startswith(("$(", "${")) or v in {"", "-", "***", "<redacted>"}


def _secret_flag_value(arg: str) -> bool:
    m = _SECRET_FLAG.match(arg.strip())
    return bool(m and m.group(3) and not _is_reference(m.group(3)))


def _bare_secret_flag(arg: str) -> bool:
    m = _SECRET_FLAG.match(arg.strip())
    return bool(m and m.group(1) and m.group(3) is None)


def _containers(ctx: AuditContext) -> Iterator[tuple[Document, PodTemplate, ContainerRef]]:
    for d, pt in ctx.workloads():
        for c in containers(pt):
            yield d, pt, c


def _resource_containers(ctx: AuditContext) -> Iterator[tuple[Document, PodTemplate, ContainerRef]]:
    """App and init containers: the API refuses resources on ephemeral (debug) containers, so they cannot be fixed."""
    for d, pt in ctx.workloads():
        for c in containers(pt, ephemeral=False):
            yield d, pt, c


@rule(
    "KN-S001",
    "Privileged container",
    Stage.AUDIT,
    "security",
    Severity.CRITICAL,
    "Remove securityContext.privileged; grant only the specific capability required.",
    "A privileged container has full access to the host (all devices, all capabilities). On OpenShift it is "
    "rejected unless the ServiceAccount is granted the 'privileged' SCC.",
    ("k8s-pss", "ocp-scc"),
    ("Privileged Container",),
)
def _s001(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        sc = c.container.get("securityContext")
        if isinstance(sc, dict) and sc.get("privileged") is True:
            yield r.finding(d, (*c.path, "securityContext", "privileged"), f"Container '{c.name}' is privileged.")


@rule(
    "KN-S002",
    "Privilege escalation not disabled",
    Stage.AUDIT,
    "security",
    Severity.MEDIUM,
    "Set securityContext.allowPrivilegeEscalation: false on every container.",
    "Required by the Pod Security 'restricted' profile; prevents setuid binaries from gaining privileges. "
    "OpenShift's restricted-v2 SCC (default for new 4.11+ installs) defaults it to false and rejects an explicit "
    "true; clusters upgraded from 4.10 or earlier may still admit pods under the legacy 'restricted' SCC.",
    ("k8s-pss", "ocp-scc"),
    ("Container with privilege escalation allowed",),
)
def _s002(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        raw_sc = c.container.get("securityContext")
        sc: dict[str, Any] = raw_sc if isinstance(raw_sc, dict) else {}
        val = sc.get("allowPrivilegeEscalation")
        path = (*c.path, "securityContext", "allowPrivilegeEscalation")
        if val is True:
            yield r.finding(
                d, path, f"Container '{c.name}' explicitly allows privilege escalation.", severity=Severity.HIGH
            )
        elif val is None:
            # restricted-v2 (new 4.11+ installs) defaults it to false; clusters upgraded from <=4.10 still
            # admit pods under the legacy 'restricted' SCC, which does not.
            sev = Severity.LOW if ctx.is_openshift else Severity.MEDIUM
            yield r.finding(
                d, path, f"Container '{c.name}' does not set allowPrivilegeEscalation: false.", severity=sev
            )


@rule(
    "KN-S003",
    "Container may run as root",
    Stage.AUDIT,
    "security",
    Severity.MEDIUM,
    "Set runAsNonRoot: true (pod or container securityContext) and build images with a non-root USER.",
    "Running as UID 0 widens the impact of a container breakout. On OpenShift the restricted-v2 SCC assigns an "
    "arbitrary non-root UID, so images must also work as a random UID in group 0.",
    ("k8s-pss", "ocp-scc"),
    ("Docker CIS 4.1: Ensure That a User for the Container Has Been Created",),
)
def _s003(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt, c in _containers(ctx):
        uid = effective_security(pt, c, "runAsUser")
        non_root = effective_security(pt, c, "runAsNonRoot")
        if uid == 0:
            yield r.finding(
                d,
                (*c.path, "securityContext", "runAsUser"),
                f"Container '{c.name}' runs as UID 0.",
                severity=Severity.HIGH,
            )
        elif non_root is not True and not (isinstance(uid, int) and uid > 0):
            sev = Severity.INFO if ctx.is_openshift else Severity.MEDIUM
            yield r.finding(
                d,
                (*c.path, "securityContext"),
                f"Container '{c.name}' does not enforce runAsNonRoot: true.",
                severity=sev,
            )


@rule(
    "KN-S004",
    "Fixed UID/fsGroup conflicts with OpenShift restricted-v2 SCC",
    Stage.AUDIT,
    "platform",
    Severity.HIGH,
    "Remove runAsUser/fsGroup and let OpenShift assign IDs from the namespace range; keep runAsNonRoot: true. If a "
    "fixed UID is truly required, bind the ServiceAccount to the nonroot-v2 SCC. (runAsGroup is not governed by "
    "SCCs and is left alone.)",
    "restricted-v2 uses MustRunAsRange for UIDs and MustRunAs for fsGroup: pods requesting IDs outside the "
    "namespace's openshift.io/sa.scc.uid-range / supplemental-groups annotations are rejected ('unable to validate "
    "against any security context constraint').",
    ("ocp-scc",),
)
def _s004(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    if not ctx.is_openshift:
        return
    for d, pt in ctx.workloads():
        psc = pt.spec.get("securityContext")
        if isinstance(psc, dict):
            for f in ("runAsUser", "fsGroup"):
                if isinstance(psc.get(f), int) and psc[f] != 0:
                    yield r.finding(
                        d,
                        (*pt.path, "securityContext", f),
                        f"Pod sets {f}: {psc[f]}; restricted-v2 will reject IDs outside the namespace range.",
                    )
        for c in containers(pt):
            csc = c.container.get("securityContext")
            if isinstance(csc, dict):
                for f in ("runAsUser",):
                    if isinstance(csc.get(f), int) and csc[f] != 0:
                        yield r.finding(
                            d,
                            (*c.path, "securityContext", f),
                            f"Container '{c.name}' sets {f}: "
                            f"{csc[f]}; restricted-v2 will reject IDs outside the namespace range.",
                        )


@rule(
    "KN-S005",
    "Dangerous Linux capabilities added",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Remove the capability; the Pod Security 'restricted' profile only allows adding NET_BIND_SERVICE.",
    "Capabilities like SYS_ADMIN or NET_ADMIN are near-root and enable container escapes.",
    ("k8s-pss",),
    ("CAP_SYS_ADMIN capability added",),
)
def _s005(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        add = get_path(c.container, ("securityContext", "capabilities", "add")) or []
        for i, cap in enumerate(add if isinstance(add, list) else []):
            cap_u = str(cap).upper().removeprefix("CAP_")
            if cap_u in DANGEROUS_CAPS:
                yield r.finding(
                    d, (*c.path, "securityContext", "capabilities", "add", i), f"Container '{c.name}' adds {cap_u}."
                )
            elif cap_u not in PSS_RESTRICTED_ALLOWED_ADD:
                yield r.finding(
                    d,
                    (*c.path, "securityContext", "capabilities", "add", i),
                    f"Container '{c.name}' adds {cap_u} (not allowed by PSS restricted).",
                    severity=Severity.MEDIUM,
                )


@rule(
    "KN-S006",
    "Capabilities not dropped",
    Stage.AUDIT,
    "security",
    Severity.LOW,
    'Set securityContext.capabilities.drop: ["ALL"].',
    "Pod Security 'restricted' requires dropping ALL capabilities. OpenShift restricted-v2 drops them for you, the "
    "legacy 'restricted' SCC (clusters upgraded from <=4.10) does not.",
    ("k8s-pss", "ocp-scc"),
    ("Drop All Capabilities",),
)
def _s006(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        drop = get_path(c.container, ("securityContext", "capabilities", "drop")) or []
        if not any(str(x).upper() == "ALL" for x in (drop if isinstance(drop, list) else [])):
            yield r.finding(
                d, (*c.path, "securityContext", "capabilities"), f"Container '{c.name}' does not drop ALL capabilities."
            )


@rule(
    "KN-S007",
    "Writable root filesystem",
    Stage.AUDIT,
    "security",
    Severity.LOW,
    "Set readOnlyRootFilesystem: true and mount emptyDir volumes for paths the app writes (e.g. /tmp).",
    "A read-only root filesystem blocks tampering and many post-exploitation techniques.",
    ("k8s-pss",),
    ("Container using read-write root filesystem",),
)
def _s007(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        if get_path(c.container, ("securityContext", "readOnlyRootFilesystem")) is not True:
            yield r.finding(d, (*c.path, "securityContext"), f"Container '{c.name}' has a writable root filesystem.")


@rule(
    "KN-S008",
    "Seccomp profile not set to RuntimeDefault",
    Stage.AUDIT,
    "security",
    Severity.LOW,
    "Set securityContext.seccompProfile.type: RuntimeDefault at pod level.",
    "Pod Security 'restricted' requires RuntimeDefault or Localhost seccomp; Unconfined disables syscall "
    "filtering. OpenShift restricted-v2 applies RuntimeDefault by default. A Localhost profile must name its file: "
    "an empty localhostProfile is the CVE-2023-2431 pattern, which kubelets before v1.24.14, v1.25.10, v1.26.5 and "
    "v1.27.2 ran without any seccomp filter.",
    ("k8s-pss", "ocp-scc", "k8s-cve-2023-2431"),
    ("Docker CIS 5.21: Ensure the default seccomp profile is not disabled",),
)
def _s008(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        pod_profile = get_path(pt.spec, ("securityContext", "seccompProfile"))
        pod_t = pod_profile.get("type") if isinstance(pod_profile, dict) else None
        for c in containers(pt):
            c_profile = get_path(c.container, ("securityContext", "seccompProfile"))
            ct = c_profile.get("type") if isinstance(c_profile, dict) else None
            eff = ct or pod_t
            profile = c_profile if ct else pod_profile
            if eff == "Unconfined":
                yield r.finding(
                    d,
                    (*c.path, "securityContext", "seccompProfile"),
                    f"Container '{c.name}' runs with seccomp Unconfined.",
                    severity=Severity.MEDIUM,
                )
            elif eff == "Localhost" and not (
                isinstance(profile, dict)
                and profile.get("localhostProfile") is not None
                and str(profile.get("localhostProfile")).strip()
            ):
                yield r.finding(
                    d,
                    (*c.path, "securityContext", "seccompProfile")
                    if ct
                    else (*pt.path, "securityContext", "seccompProfile"),
                    f"Container '{c.name}' uses seccomp type Localhost with an empty or missing localhostProfile: "
                    "CVE-2023-2431 (kubelet, fixed in v1.24.14, v1.25.10, v1.26.5 and v1.27.2) ran such containers "
                    "with no seccomp filter at all. Name the profile file (localhostProfile: profiles/app.json) or "
                    "use RuntimeDefault.",
                    severity=Severity.MEDIUM,
                )
            elif eff not in {"RuntimeDefault", "Localhost"}:
                yield r.finding(
                    d,
                    (*pt.path, "securityContext", "seccompProfile"),
                    f"Container '{c.name}' has no RuntimeDefault seccomp profile.",
                )


@rule(
    "KN-S009",
    "Host namespaces shared",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Remove hostNetwork/hostPID/hostIPC unless this is a node agent that truly needs it.",
    "Sharing host namespaces exposes host processes and network; OpenShift requires a privileged/hostnetwork SCC.",
    ("k8s-pss", "ocp-scc"),
    (
        "Docker CIS 5.9 and 5.20: Ensure that the host's network namespace is not shared",
        "Docker CIS 5.15: Ensure that the host's process namespace is not shared",
        "Docker CIS 5.16: Ensure that the host's IPC namespace is not shared",
    ),
)
def _s009(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        for f in ("hostNetwork", "hostPID", "hostIPC"):
            if pt.spec.get(f) is True:
                yield r.finding(d, (*pt.path, f), f"Pod sets {f}: true.")


@rule(
    "KN-S010",
    "hostPath volume",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Replace hostPath with a PVC, emptyDir, ConfigMap/Secret or a CSI ephemeral volume.",
    "hostPath mounts let a container read or modify the node filesystem; container runtime sockets give full "
    "node takeover.",
    ("k8s-pss",),
    ("Mounting Sensitive Host Directories", "Mount Container Runtime Socket"),
)
def _s010(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        for i, v in enumerate(pt.spec.get("volumes") or []):
            if not isinstance(v, dict) or not isinstance(v.get("hostPath"), dict):
                continue
            p = str(v["hostPath"].get("path", ""))
            crit = p in {"/", "/etc", "/var/lib/kubelet", "/proc"} or any(p.endswith(s) for s in RUNTIME_SOCKETS)
            yield r.finding(
                d,
                (*pt.path, "volumes", i, "hostPath"),
                f"Volume '{v.get('name')}' mounts host path '{p}'.",
                severity=Severity.CRITICAL if crit else Severity.HIGH,
            )


@rule(
    "KN-S011",
    "hostPort used",
    Stage.AUDIT,
    "security",
    Severity.MEDIUM,
    "Expose the container through a Service instead of hostPort.",
    "hostPort binds directly on the node, bypasses NetworkPolicy expectations and limits scheduling.",
    ("k8s-pss",),
)
def _s011(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        for i, p in enumerate(c.container.get("ports") or []):
            if isinstance(p, dict) and p.get("hostPort"):
                yield r.finding(
                    d, (*c.path, "ports", i, "hostPort"), f"Container '{c.name}' binds hostPort {p['hostPort']}."
                )


_DIGEST = re.compile(r"@sha256:[0-9a-f]{64}$")


def image_tag(image: str) -> tuple[str | None, bool]:
    """Return (tag, has_digest). Handles registry ports ('host:5000/app')."""
    has_digest = bool(_DIGEST.search(image))
    ref = image.split("@", 1)[0]
    last = ref.rsplit("/", 1)[-1]
    tag = last.split(":", 1)[1] if ":" in last else None
    return tag, has_digest


@rule(
    "KN-S012",
    "Mutable image reference",
    Stage.AUDIT,
    "supply-chain",
    Severity.MEDIUM,
    "Pin an explicit version tag, ideally an immutable digest (image@sha256:...).",
    "':latest' or untagged images change underneath you, break rollbacks and defeat image scanning/signing.",
    ("k8s-images",),
    ("Latest tag",),
)
def _s012(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        image = c.container.get("image")
        if not isinstance(image, str) or not image:
            yield r.finding(d, c.path, f"Container '{c.name}' has no image.", severity=Severity.HIGH)
            continue
        tag, digest = image_tag(image)
        if digest:
            continue
        if tag in (None, "latest"):
            yield r.finding(d, (*c.path, "image"), f"Container '{c.name}' uses mutable image '{image}'.")
        else:
            yield r.finding(
                d,
                (*c.path, "image"),
                f"Container '{c.name}' image '{image}' is not pinned by digest.",
                severity=Severity.INFO,
            )


@rule(
    "KN-S013",
    "Secret value hard-coded in environment",
    Stage.AUDIT,
    "secrets",
    Severity.HIGH,
    "Move the value to a Secret and reference it with valueFrom.secretKeyRef (or an external secret store).",
    "Literal credentials in manifests leak through Git history, `oc get -o yaml`, logs and audit trails.",
    ("k8s-secrets-good-practices",),
    ("Environment Variable Contains Secret",),
)
def _s013(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        for i, e in enumerate(c.container.get("env") or []):
            if not isinstance(e, dict) or not isinstance(e.get("value"), str) or _is_reference(e["value"]):
                continue
            if SENSITIVE_ENV.search(str(e.get("name", ""))):
                yield r.finding(
                    d, (*c.path, "env", i, "value"), f"Container '{c.name}' sets {e['name']} as a literal value."
                )
            elif _EMBEDDED_SECRET.search(e["value"]):
                yield r.finding(
                    d,
                    (*c.path, "env", i, "value"),
                    f"Container '{c.name}' env {e.get('name')} embeds a credential (URL password, key or token).",
                )
        for field_name in ("command", "args"):
            items = c.container.get(field_name)
            if not isinstance(items, list):
                continue
            strs = [x if isinstance(x, str) else "" for x in items]
            for i, arg in enumerate(strs):
                nxt = strs[i + 1] if i + 1 < len(strs) else ""
                if (
                    _secret_flag_value(arg)
                    or _EMBEDDED_SECRET.search(arg)
                    or (_bare_secret_flag(arg) and nxt and not nxt.startswith("-") and not _is_reference(nxt))
                ):
                    yield r.finding(
                        d,
                        (*c.path, field_name, i),
                        f"Container '{c.name}' passes a literal credential in {field_name}[{i}] (visible in the pod "
                        "spec and the process list).",
                    )


@rule(
    "KN-S014",
    "ServiceAccount token automounted",
    Stage.AUDIT,
    "security",
    Severity.LOW,
    "Set automountServiceAccountToken: false on the pod (or ServiceAccount) unless the app calls the API.",
    "A mounted token turns any RCE into authenticated Kubernetes API access.",
    ("k8s-rbac-good-practices",),
    ("Pod Service Account Token Automatically Mounted",),
)
def _s014(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    sa_opt_out = {
        (ctx.ns(d), d.name)
        for d in ctx.by_kind("ServiceAccount")
        if isinstance(d.data, dict) and d.data.get("automountServiceAccountToken") is False
    }
    for d, pt in ctx.workloads():
        if pt.spec.get("automountServiceAccountToken") is False:
            continue
        sa = str(pt.spec.get("serviceAccountName") or "default")
        if (ctx.ns(d), sa) in sa_opt_out and pt.spec.get("automountServiceAccountToken") is not True:
            continue
        yield r.finding(d, pt.path, f"Pod automounts the token of ServiceAccount '{sa}'.")


def _rules_of(d: Document) -> list[tuple[int, dict[str, Any]]]:
    rules = d.data.get("rules") if isinstance(d.data, dict) else None
    return [(i, x) for i, x in enumerate(rules or []) if isinstance(x, dict)]


@rule(
    "KN-S015",
    "RBAC wildcard grants",
    Stage.AUDIT,
    "rbac",
    Severity.HIGH,
    "Enumerate the exact apiGroups, resources and verbs needed.",
    "Wildcards grant every current and future resource/verb, including secrets and escalation paths.",
    ("k8s-rbac-good-practices",),
)
def _s015(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Role", "ClusterRole"):
        for i, rr in _rules_of(d):
            wild = [k for k in ("verbs", "resources", "apiGroups") if "*" in (rr.get(k) or [])]
            if wild:
                yield r.finding(d, ("rules", i), f"Rule uses '*' in {', '.join(wild)}.")


@rule(
    "KN-S016",
    "Binding to cluster-admin",
    Stage.AUDIT,
    "rbac",
    Severity.CRITICAL,
    "Bind a narrowly scoped Role instead; cluster-admin should only be held by break-glass identities.",
    "cluster-admin is full control of the cluster.",
    ("k8s-rbac-good-practices",),
)
def _s016(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("ClusterRoleBinding", "RoleBinding"):
        if get_path(d.data, ("roleRef", "name")) == "cluster-admin":
            subjects = [f"{s.get('kind')}/{s.get('name')}" for s in d.data.get("subjects") or [] if isinstance(s, dict)]
            sev = Severity.CRITICAL if d.kind == "ClusterRoleBinding" else Severity.HIGH
            yield r.finding(d, ("roleRef", "name"), f"{d.kind} grants cluster-admin to {subjects}.", severity=sev)


ESCALATION_VERBS = frozenset({"escalate", "bind", "impersonate"})


WORKLOAD_RESOURCES = frozenset(
    {
        "pods",
        "deployments",
        "replicasets",
        "statefulsets",
        "daemonsets",
        "jobs",
        "cronjobs",
        "replicationcontrollers",
        "deploymentconfigs",
    }
)


WRITE_VERBS = frozenset({"create", "patch", "update", "*"})


def _writes(rr: dict[str, Any], resource: str) -> bool:
    return resource in {str(x) for x in rr.get("resources") or []} and bool(
        {str(v) for v in rr.get("verbs") or []} & WRITE_VERBS
    )


@rule(
    "KN-S017",
    "RBAC privilege-escalation paths",
    Stage.AUDIT,
    "rbac",
    Severity.HIGH,
    "Remove escalate/bind/impersonate, cluster-wide secret reads, nodes/proxy, pod exec, ephemeral containers, "
    "ControllerRevision writes and workload creation unless essential; where they are, enforce Pod Security "
    "restricted in that namespace, and run kube-controller-manager v1.34.12, v1.35.9, v1.36.5, v1.37.1 or later.",
    "These permissions let a subject obtain more privileges than it was granted. Only the StatefulSet and DaemonSet "
    "controllers need to write ControllerRevisions (the built-in edit and admin roles do not grant it): with write "
    "access to StatefulSets too, CVE-2026-2270 (kube-controller-manager up to v1.34.11, v1.35.8, v1.36.4 and "
    "v1.37.0) let a namespace user create pods in other namespaces.",
    ("k8s-rbac-good-practices", "k8s-cve-2026-2270", "k8s-rbac-bootstrap-policy"),
)
def _s017(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Role", "ClusterRole"):
        role_rules = _rules_of(d)
        writes_sts = any(_writes(x, "statefulsets") for _, x in role_rules)
        for i, rr in role_rules:
            if _writes(rr, "controllerrevisions"):
                pair = (
                    "this role also writes StatefulSets, the pair CVE-2026-2270 needs"
                    if writes_sts
                    else "with write access to StatefulSets from any role, this is CVE-2026-2270"
                )
                yield r.finding(
                    d,
                    ("rules", i, "resources"),
                    f"Can write ControllerRevisions: {pair} (kube-controller-manager up to v1.34.11, v1.35.8, v1.36.4 "
                    "and v1.37.0; fixed in v1.34.12, v1.35.9, v1.36.5 and v1.37.1), which lets a namespace user "
                    "create pods in other namespaces. Only controllers need to write ControllerRevisions.",
                    severity=Severity.HIGH if writes_sts else Severity.MEDIUM,
                )
        for i, rr in role_rules:
            verbs = {str(v) for v in rr.get("verbs") or []}
            resources = {str(x) for x in rr.get("resources") or []}
            if verbs & ESCALATION_VERBS:
                yield r.finding(d, ("rules", i, "verbs"), f"Grants {sorted(verbs & ESCALATION_VERBS)}.")
            if "secrets" in resources and verbs & {"get", "list", "watch", "*"}:
                sev = Severity.HIGH if d.kind == "ClusterRole" else Severity.LOW
                yield r.finding(d, ("rules", i, "resources"), f"{d.kind} can read Secrets.", severity=sev)
            if resources & {"pods/exec", "pods/attach"} and verbs & {"create", "*"}:
                yield r.finding(d, ("rules", i, "resources"), "Grants exec/attach into pods.", severity=Severity.MEDIUM)
            if "nodes/proxy" in resources:
                yield r.finding(d, ("rules", i, "resources"), "Grants nodes/proxy (kubelet API access).")
            # Kubernetes RBAC good practices, "Workload creation" and "Persistent volume creation":
            # https://github.com/kubernetes/website/blob/main/content/en/docs/concepts/security/rbac-good-practices.md
            if resources & WORKLOAD_RESOURCES and verbs & {"create", "patch", "update", "*"}:
                sev = Severity.HIGH if d.kind == "ClusterRole" else Severity.MEDIUM
                yield r.finding(
                    d,
                    ("rules", i, "resources"),
                    f"Can create or change {', '.join(sorted(resources & WORKLOAD_RESOURCES))}: their pods can run as "
                    "any ServiceAccount in the namespace and mount its Secrets and volumes.",
                    severity=sev,
                )
            if "pods/ephemeralcontainers" in resources and verbs & {"patch", "update", "*"}:
                yield r.finding(
                    d,
                    ("rules", i, "resources"),
                    "Can add ephemeral containers to running pods: code runs in the pod, like exec.",
                    severity=Severity.MEDIUM,
                )
            if "persistentvolumes" in resources and verbs & {"create", "*"}:
                yield r.finding(d, ("rules", i, "resources"), "Can create PersistentVolumes, including hostPath.")


@rule(
    "KN-S018",
    "Secret material committed in manifests",
    Stage.AUDIT,
    "secrets",
    Severity.MEDIUM,
    "Deliver secrets with an external secret store (External Secrets Operator, Vault, AWS Secrets Manager on "
    "ROSA) or Sealed Secrets; never commit base64 'data' to Git.",
    "base64 is an encoding, not encryption.",
    ("k8s-secrets-good-practices",),
)
def _s018(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Secret"):
        if isinstance(d.data, dict) and (d.data.get("data") or d.data.get("stringData")):
            if d.data.get("type") == "kubernetes.io/service-account-token":
                continue
            yield r.finding(
                d, ("data",) if d.data.get("data") else ("stringData",), "Secret contains inline key material."
            )


@rule(
    "KN-S019",
    "Permissive SecurityContextConstraints",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Prefer the built-in restricted-v2 / nonroot-v2 SCCs; custom SCCs must not allow privileged, host "
    "namespaces, host directories or RunAsAny UIDs.",
    "A permissive SCC bound to a ServiceAccount defeats OpenShift's default pod isolation.",
    ("ocp-scc",),
)
def _s019(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("SecurityContextConstraints"):
        data = d.data
        bad = [
            k
            for k in (
                "allowPrivilegedContainer",
                "allowHostNetwork",
                "allowHostPID",
                "allowHostIPC",
                "allowHostDirVolumePlugin",
                "allowHostPorts",
                "allowPrivilegeEscalation",
            )
            if data.get(k) is True
        ]
        if get_path(data, ("runAsUser", "type")) == "RunAsAny":
            bad.append("runAsUser: RunAsAny")
        if bad:
            yield r.finding(d, (), f"SCC allows: {', '.join(bad)}.")


@rule(
    "KN-S020",
    "Unmasked /proc",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Remove securityContext.procMount: Unmasked.",
    "Unmasked /proc exposes host kernel interfaces.",
    ("k8s-pss",),
)
def _s020(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        if get_path(c.container, ("securityContext", "procMount")) == "Unmasked":
            yield r.finding(d, (*c.path, "securityContext", "procMount"), f"Container '{c.name}' unmasks /proc.")


@rule(
    "KN-S021",
    "gitRepo volume",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Clone with an init container into an emptyDir volume that the app container mounts (the replacement the "
    "Kubernetes docs give), and remove the gitRepo volume.",
    "gitRepo volumes are deprecated since Kubernetes 1.11, off by default from 1.33 (GitRepoVolumeDriver feature "
    "gate) and gone after 1.35. CVE-2024-10220 (CVSS 8.1; kubelet, fixed in v1.28.12, v1.29.7, v1.30.3 and v1.31.0) "
    "let a user who can create a pod run commands outside the container through a gitRepo volume, and "
    "CVE-2025-1767 (every version, no fix) lets a pod read local git repositories on the node through one.",
    ("k8s-cve-2024-10220", "k8s-cve-2025-1767", "k8s-volumes-gitrepo"),
)
def _s021(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    target = parse_minor(ctx.k8s_version)
    for d, pt in ctx.workloads():
        for i, v in enumerate(pt.spec.get("volumes") or []):
            if not isinstance(v, dict) or "gitRepo" not in v:
                continue
            raw_git = v.get("gitRepo")
            git: dict[str, Any] = raw_git if isinstance(raw_git, dict) else {}
            repo = str(git.get("repository") or "")
            local = (
                f" Its repository '{repo}' is a path on the node: the CVE-2025-1767 pattern."
                if repo.startswith("/")
                else ""
            )
            if target >= (1, 36):
                state = (
                    f"Kubernetes {ctx.k8s_version} no longer has the gitRepo driver (last served by v1.35): the pod "
                    "cannot start."
                )
            elif target >= (1, 33):
                state = (
                    f"On Kubernetes {ctx.k8s_version} the GitRepoVolumeDriver feature gate is off by default, so the "
                    "pod does not start unless the cluster turned it on."
                )
            else:
                state = "gitRepo is deprecated since Kubernetes 1.11 and disabled by default from 1.33."
            yield r.finding(
                d,
                (*pt.path, "volumes", i, "gitRepo"),
                f"Volume '{v.get('name')}' is a gitRepo volume: CVE-2024-10220 (kubelet, fixed in v1.28.12, v1.29.7, "
                "v1.30.3 and v1.31.0) ran attacker-chosen commands on the node through gitRepo volumes, and "
                f"CVE-2025-1767 (every version, no fix) reads local git repositories through them.{local} {state} "
                "Clone with an init container into an emptyDir volume instead.",
            )


_SYSCTL_META = ("+", "=")


@rule(
    "KN-S022",
    "Pod sysctl name or value contains '+' or '='",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Remove the sysctl, or write it as one plain name and one plain value (a sysctl never needs '+' or '=' in "
    "either); on OpenShift keep to the safe sysctls or the ones a Tuned profile allows.",
    "CVE-2022-0811 ('cr8escape', CRI-O 1.19 to 1.24.0, fixed in 1.19.6, 1.20.7, 1.21.6, 1.22.3, 1.23.2 and 1.24.0) "
    "passed a sysctl whose value carried '+' to set kernel.core_pattern and escape the container with root on the "
    "node; OpenShift's container runtime is CRI-O, and the GitHub advisory names an admission webhook that denies "
    "pods with a '+' in a sysctl value as the mitigation.",
    ("ghsa-cve-2022-0811",),
)
def _s022(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        sysctls = get_path(pt.spec, ("securityContext", "sysctls"))
        for i, s in enumerate(sysctls if isinstance(sysctls, list) else []):
            if not isinstance(s, dict):
                continue
            name, value = str(s.get("name", "")), str(s.get("value", ""))
            if any(ch in name or ch in value for ch in _SYSCTL_META):
                yield r.finding(
                    d,
                    (*pt.path, "securityContext", "sysctls", i),
                    f"Pod sysctl '{name}' = '{value}' contains '+' or '=': the CVE-2022-0811 (cr8escape) pattern, "
                    "which CRI-O before 1.19.6, 1.20.7, 1.21.6, 1.22.3, 1.23.2 and 1.24.0 turned into a container "
                    "escape through kernel.core_pattern. Remove the sysctl or write one plain name and value.",
                )


_PROC_DIR = re.compile(r"^/proc(?:/|\Z)")


@rule(
    "KN-S023",
    "Container workingDir under /proc",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Set workingDir to a directory that exists in the image (/app, /opt/app-root) or leave it unset, and run nodes "
    "with runc 1.1.12 or later.",
    "CVE-2024-21626 ('Leaky Vessels', CVSS 8.6; runc 1.0.0-rc93 to 1.1.11, fixed in 1.1.12) let a container whose "
    "working directory was under /proc/self/fd/ start with a working directory in the host filesystem through a "
    "leaked file descriptor: a container breakout to the host filesystem. The advisory's mitigation is to permit "
    "only a process.cwd of / and to deny working directories under /proc.",
    ("ghsa-cve-2024-21626",),
)
def _s023(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        wd = c.container.get("workingDir")
        if isinstance(wd, str) and _PROC_DIR.match(wd.strip()):
            yield r.finding(
                d,
                (*c.path, "workingDir"),
                f"Container '{c.name}' sets workingDir '{wd.strip()}' under /proc: the CVE-2024-21626 (Leaky Vessels) "
                "pattern, which runc before 1.1.12 turned into a breakout to the node filesystem through a leaked "
                "file descriptor. Use a directory inside the image.",
            )


@rule(
    "KN-S024",
    "ingress-nginx controller image below the fixed releases",
    Stage.AUDIT,
    "supply-chain",
    Severity.HIGH,
    "Run a release that fixes every advisory below (v1.13.9, v1.14.5, v1.15.1 or later), disable the validating "
    "webhook (--validating-webhook) until the controller is at least v1.11.5 or v1.12.1, and plan the move to a "
    "Gateway API implementation: the project is retired and fixes nothing found after its last release.",
    "The controller image tag is a release; the Kubernetes CVE feed names the releases that fix each ingress-nginx "
    "CVE. CVE-2025-1974 (CVSS 9.8, fixed in v1.11.5 and v1.12.1) gives anyone on the pod network code execution "
    "in the controller through its validating admission webhook; the later fixes close configuration injection "
    "through annotations and paths (CVE-2025-15566 in v1.12.5/v1.13.1; CVE-2026-1580, CVE-2026-24512, "
    "CVE-2026-24513 and CVE-2026-24514 in v1.13.7/v1.14.3; CVE-2026-3288 in v1.13.8/v1.14.4/v1.15.0; CVE-2026-4342 "
    "in v1.13.9/v1.14.5/v1.15.1).",
    tuple(dict.fromkeys(c for a in INGRESS_NGINX_ADVISORIES for c in a.citations)) + ("ingress-nginx-retired",),
)
def _s024(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _containers(ctx):
        image = c.container.get("image")
        if not isinstance(image, str):
            continue
        version = ingress_nginx_version(image)
        if version is None:
            continue
        hits = [a for a in INGRESS_NGINX_ADVISORIES if a.affects(version)]
        if not hits:
            continue
        args = c.container.get("args")
        webhook = any(str(a).startswith("--validating-webhook") for a in (args if isinstance(args, list) else []))
        rce = any(_WEBHOOK_RCE in a.cves for a in hits)
        parts = [f"{', '.join(a.cves)}: {a.summary} (fixed in {', '.join('v' + f for f in a.fixed)})" for a in hits]
        tag = "v{}.{}.{}".format(*version)
        yield r.finding(
            d,
            (*c.path, "image"),
            f"Container '{c.name}' runs ingress-nginx {tag}, which is affected by {len(hits)} published advisory(ies): "
            + "; ".join(parts)
            + "."
            + (
                " The validating webhook is on (--validating-webhook), so CVE-2025-1974 is reachable from the pod "
                "network without credentials."
                if webhook and rce
                else ""
            ),
            severity=Severity.CRITICAL if webhook and rce else Severity.HIGH,
        )


# Characters a shell or PowerShell treats as syntax. A volume path (a subPath, a local PersistentVolume path) never
# needs them; RE2 too (kube_noob.generate.policies puts it into CEL), with quotes and the backtick as \x escapes.
COMMAND_META = r"[$;&|<>\x60\x27\x22\r\n]"
_COMMAND_META = re.compile(COMMAND_META)


def _meta_chars(value: str) -> str:
    """The shell characters in ``value``, quoted: "the shell character(s) '$' ';'"."""
    return "the shell character(s) " + " ".join(sorted({repr(ch) for ch in value if _COMMAND_META.match(ch)}))


def _targets_windows(pt: PodTemplate) -> bool:
    if str(get_path(pt.spec, ("os", "name")) or "").lower() == "windows":
        return True
    sel = pt.spec.get("nodeSelector")
    if isinstance(sel, dict) and str(sel.get("kubernetes.io/os", "")).lower() == "windows":
        return True
    required = get_path(pt.spec, ("affinity", "nodeAffinity", "requiredDuringSchedulingIgnoredDuringExecution"))
    terms = required.get("nodeSelectorTerms") if isinstance(required, dict) else None
    for term in terms if isinstance(terms, list) else []:
        exprs = term.get("matchExpressions") if isinstance(term, dict) else None
        for e in exprs if isinstance(exprs, list) else []:
            if isinstance(e, dict) and e.get("key") == "kubernetes.io/os" and "windows" in (e.get("values") or []):
                return True
    return False


@rule(
    "KN-S025",
    "volumeMount subPath carries shell or PowerShell characters",
    Stage.AUDIT,
    "security",
    Severity.HIGH,
    "Use a plain relative path for subPath (letters, digits, '-', '_', '.', '/'), and run Windows nodes with kubelet "
    "v1.24.17, v1.25.13, v1.26.8, v1.27.5, v1.28.1 or later.",
    "CVE-2023-3676 (CVSS 8.8; kubelet up to v1.24.16, v1.25.12, v1.26.7, v1.27.4 and v1.28.0, fixed in v1.24.17, "
    "v1.25.13, v1.26.8, v1.27.5 and v1.28.1): on Windows nodes kubelet put a pod's subPath into a PowerShell "
    "command, so anyone who could create a pod ran commands as SYSTEM on the node. The fix passes the path in an "
    "environment variable; the feed names pod create events with embedded PowerShell commands as the sign of "
    "exploitation. A subPath is a path inside the volume and never needs these characters.",
    ("k8s-cve-2023-3676", "k8s-fix-cve-2023-3676"),
)
def _s025(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt, c in _containers(ctx):
        mounts = c.container.get("volumeMounts")
        windows = _targets_windows(pt)
        for i, m in enumerate(mounts if isinstance(mounts, list) else []):
            sub = m.get("subPath") if isinstance(m, dict) else None
            if not isinstance(sub, str) or not _COMMAND_META.search(sub):
                continue
            where = "a Windows node" if windows else "any Windows node it lands on"
            yield r.finding(
                d,
                (*c.path, "volumeMounts", i, "subPath"),
                f"Container '{c.name}' mounts '{m.get('name')}' with subPath {sub!r}, which carries "
                f"{_meta_chars(sub)}: the CVE-2023-3676 pattern, where kubelet before v1.24.17, v1.25.13, v1.26.8, "
                f"v1.27.5 and v1.28.1 ran the subPath through PowerShell as SYSTEM on {where}. Use a plain relative "
                "path.",
                severity=Severity.HIGH if windows else Severity.MEDIUM,
            )


# A ConfigMap key that names a credential (DB_PASSWORD, redis.password, api-key, client_secret, credentials), and a
# line of a config file in a value that sets one (password=..., "token": "..."). A key that ends in plain "secret"
# usually names a Secret, so it is left out. RE2 too: kube_noob.generate.policies puts both into CEL.
CREDENTIAL_NAME = (
    r"(?:password|passwd|token|api[-_]?key|access[-_]?key|secret[-_]?key|private[-_]?key|client[-_]?secret|"
    r"credentials?)"
)
CONFIGMAP_CREDENTIAL_KEY = r"(?i)^(?:[a-z0-9]+[._-])*" + CREDENTIAL_NAME + r"$"
CONFIGMAP_CREDENTIAL_LINE = (
    r"(?im)^[ \t]*(?:export[ \t]+)?[\x22\x27]?[a-z0-9_.-]*" + CREDENTIAL_NAME + r"[\x22\x27]?[ \t]*[=:][ \t]*"
    r"[\x22\x27]?[^\s$<{*#%\x22\x27-]"
)
_CM_KEY = re.compile(CONFIGMAP_CREDENTIAL_KEY[:-1] + r"\Z")
_CM_LINE = re.compile(CONFIGMAP_CREDENTIAL_LINE)


@rule(
    "KN-S026",
    "Credential stored in a ConfigMap",
    Stage.AUDIT,
    "secrets",
    Severity.HIGH,
    "Move the value into a Secret (created outside Git: an external secret store or Sealed Secrets) and mount or "
    "reference it; in a Helm chart, render credentials into a Secret template, never into a ConfigMap.",
    "A ConfigMap does not provide secrecy or encryption: it is not covered by encryption of Secrets at rest, and the "
    "built-in view role reads ConfigMaps but not Secrets, so everyone with read access to the namespace reads the "
    "credential. Flags a key that names a credential with a literal value, a URL with a password, a private key, an "
    "access key id or a token in any value, and a password=... or token: ... line in a config file value.",
    ("k8s-configmap", "k8s-secrets-good-practices", "k8s-rbac-bootstrap-policy"),
)
def _s026(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("ConfigMap"):
        data = d.data.get("data") if isinstance(d.data, dict) else None
        if not isinstance(data, dict):
            continue
        for key in sorted(data, key=str):
            value = "" if data[key] is None else str(data[key])
            if _CM_KEY.match(str(key)) and not _is_reference(value):
                why = "names a credential and holds a literal value"
            elif _EMBEDDED_SECRET.search(value):
                why = "embeds a credential (a URL password, a private key, an access key id or a token)"
            elif _CM_LINE.search(value):
                why = "sets a credential on a line of the file it holds (password=..., token: ...)"
            else:
                continue
            yield r.finding(
                d,
                ("data", str(key)),
                f"ConfigMap key '{key}' {why}; a ConfigMap is not secret (readable with the view role, not "
                "encrypted at rest). Move it to a Secret.",
            )


@rule(
    "KN-S027",
    "Legacy ServiceAccount token Secret",
    Stage.AUDIT,
    "secrets",
    Severity.MEDIUM,
    "Delete the Secret and get short-lived tokens instead: a projected serviceAccountToken volume in the pod, or the "
    "TokenRequest API (kubectl create token) for a client outside the cluster.",
    "A Secret of type kubernetes.io/service-account-token is a legacy mechanism that holds a long-lived, non-expiring "
    "ServiceAccount token; the Kubernetes docs say to create one only when the TokenRequest API cannot be used and "
    "the exposure of a non-expiring token in a readable API object is acceptable. Anyone who can read Secrets in the "
    "namespace can act as that ServiceAccount until the Secret is deleted.",
    ("k8s-secret-sa-token", "k8s-rbac-good-practices"),
)
def _s027(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Secret"):
        if isinstance(d.data, dict) and d.data.get("type") == "kubernetes.io/service-account-token":
            sa = get_path(d.data, ("metadata", "annotations", "kubernetes.io/service-account.name"))
            yield r.finding(
                d,
                ("type",),
                f"Secret is a legacy token Secret for ServiceAccount '{sa or '?'}': the token never expires and anyone "
                "who can read Secrets in the namespace can use it. Use a projected serviceAccountToken volume or "
                "kubectl create token.",
            )


# Subjects that are everyone of a kind, with what a binding to them means and the severity of a cluster-wide grant.
_ANYONE = "anyone who can reach the API server"
EVERYONE_SUBJECTS: dict[tuple[str, str], tuple[str, Severity]] = {
    ("Group", "system:unauthenticated"): (f"every unauthenticated request, {_ANYONE}", Severity.CRITICAL),
    ("User", "system:anonymous"): (f"anonymous requests, {_ANYONE}", Severity.CRITICAL),
    ("Group", "system:authenticated"): ("every user and every ServiceAccount of every namespace", Severity.HIGH),
    ("Group", "system:serviceaccounts"): ("every ServiceAccount of every namespace", Severity.HIGH),
    ("Group", "system:authenticated:oauth"): ("every user who logs in through OpenShift OAuth", Severity.HIGH),
}
RBAC_DEFAULTS_LABEL = ("kubernetes.io/bootstrapping", "rbac-defaults")


@rule(
    "KN-S028",
    "RBAC binding grants a role to everyone",
    Stage.AUDIT,
    "rbac",
    Severity.HIGH,
    "Bind the role to the ServiceAccounts, users or groups that need it, never to system:unauthenticated, "
    "system:anonymous, system:authenticated or system:serviceaccounts.",
    "The Kubernetes RBAC good practices ask to review bindings for the system:unauthenticated group and remove them, "
    "as they give access to anyone who can contact the API server at a network level. system:authenticated is every "
    "user and every ServiceAccount token in the cluster (a token stolen from any pod works), and "
    "system:serviceaccounts every ServiceAccount of every namespace. The built-in bindings (system: names, label "
    "kubernetes.io/bootstrapping: rbac-defaults) are left alone.",
    ("k8s-rbac-good-practices", "k8s-rbac-subjects"),
)
def _s028(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    key, value = RBAC_DEFAULTS_LABEL
    for d in ctx.by_kind("RoleBinding", "ClusterRoleBinding"):
        labels = get_path(d.data, ("metadata", "labels"))
        if d.name.startswith("system:") or (isinstance(labels, dict) and labels.get(key) == value):
            continue
        role = get_path(d.data, ("roleRef", "name"))
        subjects = get_path(d.data, ("subjects",))
        for i, s in enumerate(subjects if isinstance(subjects, list) else []):
            if not isinstance(s, dict):
                continue
            hit = EVERYONE_SUBJECTS.get((str(s.get("kind")), str(s.get("name"))))
            if hit is None:
                continue
            who, sev = hit
            if d.kind == "RoleBinding":
                sev = Severity(sev - 1)
            scope = "in every namespace" if d.kind == "ClusterRoleBinding" else f"in namespace {ctx.ns(d)}"
            yield r.finding(
                d,
                ("subjects", i),
                f"{d.kind} grants {get_path(d.data, ('roleRef', 'kind')) or 'role'} '{role}' {scope} to "
                f"{s.get('kind')} {s.get('name')}: {who}.",
                severity=sev,
            )


# =====================================================================================================
# AUDIT - network exposure
# =====================================================================================================


@rule(
    "KN-N001",
    "Namespace has workloads but no NetworkPolicy",
    Stage.AUDIT,
    "network",
    Severity.MEDIUM,
    "Add a default-deny ingress NetworkPolicy plus explicit allows (router/ingress controller, monitoring, "
    "same-app traffic).",
    "Without NetworkPolicy every pod in the cluster can reach these pods (lateral movement).",
    ("k8s-networkpolicy",),
    ("Deployments should have at least one ingress Network Policy",),
)
def _n001(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    netpol_ns = {ctx.ns(d) for d in ctx.by_kind("NetworkPolicy")}
    flagged: set[str] = set()
    for d, _pt in ctx.workloads():
        ns = ctx.ns(d)
        if d.kind in LONG_RUNNING_KINDS | {"Pod"} and ns not in netpol_ns and ns not in flagged:
            flagged.add(ns)
            yield r.finding(d, ("metadata",), f"No NetworkPolicy for namespace {ns} in this bundle.")


@rule(
    "KN-N002",
    "Route without TLS",
    Stage.AUDIT,
    "network",
    Severity.HIGH,
    "Add spec.tls with termination: edge (or reencrypt/passthrough) and insecureEdgeTerminationPolicy: Redirect.",
    "Plain-HTTP Routes expose credentials and session cookies to anyone on the path.",
    ("ocp-routes",),
)
def _n002(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Route"):
        tls = get_path(d.data, ("spec", "tls"))
        if not isinstance(tls, dict):
            yield r.finding(d, ("spec",), "Route serves plain HTTP (no spec.tls).")
        elif tls.get("insecureEdgeTerminationPolicy") == "Allow":
            yield r.finding(
                d,
                ("spec", "tls", "insecureEdgeTerminationPolicy"),
                "insecureEdgeTerminationPolicy: Allow also serves plain HTTP.",
                severity=Severity.MEDIUM,
            )


@rule(
    "KN-N003",
    "Ingress without TLS",
    Stage.AUDIT,
    "network",
    Severity.MEDIUM,
    "Add spec.tls with a certificate Secret (cert-manager can issue it).",
    "Plain-HTTP ingress exposes traffic in transit.",
    ("k8s-networkpolicy",),
)
def _n003(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Ingress"):
        if not get_path(d.data, ("spec", "tls")):
            yield r.finding(d, ("spec",), "Ingress has no spec.tls.")


# Annotation -> values that make a cloud load balancer internal-only (documented by each provider / controller).
INTERNAL_LB_ANNOTATIONS: dict[str, frozenset[str]] = {
    "service.beta.kubernetes.io/aws-load-balancer-internal": frozenset({"true", "0.0.0.0/0"}),
    "service.beta.kubernetes.io/aws-load-balancer-scheme": frozenset({"internal"}),  # AWS Load Balancer Controller
    "service.beta.kubernetes.io/azure-load-balancer-internal": frozenset({"true"}),
    "networking.gke.io/load-balancer-type": frozenset({"internal"}),
    "cloud.google.com/load-balancer-type": frozenset({"internal"}),
    "service.beta.kubernetes.io/openstack-internal-load-balancer": frozenset({"true"}),
    "service.beta.kubernetes.io/oci-load-balancer-internal": frozenset({"true"}),
    "service.kubernetes.io/ibm-load-balancer-cloud-provider-ip-type": frozenset({"private"}),
}


@rule(
    "KN-N004",
    "LoadBalancer Service open to the internet",
    Stage.AUDIT,
    "network",
    Severity.MEDIUM,
    "Set spec.loadBalancerSourceRanges, or make it internal (on AWS/ROSA: annotation "
    'service.beta.kubernetes.io/aws-load-balancer-internal: "true"), or front it with a Route/Ingress.',
    "A public cloud load balancer without source ranges is reachable from anywhere.",
    ("k8s-service-lb",),
    ("Deployments with externally exposed endpoints",),
)
def _n004(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Service"):
        if get_path(d.data, ("spec", "type")) != "LoadBalancer":
            continue
        ann = get_path(d.data, ("metadata", "annotations")) or {}
        internal = isinstance(ann, dict) and any(
            str(ann.get(k, "")).strip().lower() in vals for k, vals in INTERNAL_LB_ANNOTATIONS.items()
        )
        ranges = get_path(d.data, ("spec", "loadBalancerSourceRanges")) or []
        if internal:
            continue
        if not ranges:
            yield r.finding(
                d, ("spec", "type"), "type: LoadBalancer without loadBalancerSourceRanges or an internal annotation."
            )
        elif isinstance(ranges, list) and any(str(x).strip() in {"0.0.0.0/0", "::/0"} for x in ranges):
            yield r.finding(
                d,
                ("spec", "loadBalancerSourceRanges"),
                "loadBalancerSourceRanges includes 0.0.0.0/0 or ::/0, which allows the whole internet.",
            )


@rule(
    "KN-N005",
    "NodePort Service",
    Stage.AUDIT,
    "network",
    Severity.LOW,
    "Prefer ClusterIP + Route/Ingress; NodePorts open a port on every node.",
    "NodePorts widen the attack surface.",
    ("k8s-service-lb",),
)
def _n005(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Service"):
        if get_path(d.data, ("spec", "type")) == "NodePort":
            yield r.finding(d, ("spec", "type"), "type: NodePort exposes a port on every node.")


_ANY_CIDR = {"0.0.0.0/0", "::/0"}


@rule(
    "KN-N006",
    "EgressFirewall rule is shadowed",
    Stage.AUDIT,
    "network",
    Severity.HIGH,
    "Put specific Allow rules first and the catch-all Deny 0.0.0.0/0 last.",
    "EgressFirewall rules are evaluated in order and the first match wins, so an early catch-all Deny makes every "
    "later Allow dead code.",
    ("ocp-egressfirewall",),
)
def _n006(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("EgressFirewall"):
        egress = get_path(d.data, ("spec", "egress")) or []
        catch_all_at: int | None = None
        for i, e in enumerate(egress):
            if not isinstance(e, dict):
                continue
            cidr = get_path(e, ("to", "cidrSelector"))
            if catch_all_at is not None:
                yield r.finding(
                    d,
                    ("spec", "egress", i),
                    f"Rule {i} ({e.get('type')}) can never match: rule "
                    f"{catch_all_at} already matches all destinations.",
                )
            elif cidr in _ANY_CIDR and not e.get("ports"):
                catch_all_at = i


@rule(
    "KN-N007",
    "NetworkPolicy allows all ingress",
    Stage.AUDIT,
    "network",
    Severity.MEDIUM,
    "Restrict 'from' to specific namespaceSelector/podSelector peers and ports.",
    "An ingress rule of {} admits traffic from every pod and every external source.",
    ("k8s-networkpolicy",),
)
def _n007(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("NetworkPolicy"):
        for i, rule_ in enumerate(get_path(d.data, ("spec", "ingress")) or []):
            if not isinstance(rule_, dict):
                continue
            peers = rule_.get("from")
            if not peers:
                if not rule_.get("ports"):
                    yield r.finding(d, ("spec", "ingress", i), "Ingress rule admits all sources on all ports.")
                continue
            for j, peer in enumerate(peers if isinstance(peers, list) else []):
                if not isinstance(peer, dict):
                    continue
                ipb = peer.get("ipBlock")
                if isinstance(ipb, dict) and str(ipb.get("cidr", "")).strip() in _ANY_CIDR and not ipb.get("except"):
                    yield r.finding(
                        d,
                        ("spec", "ingress", i, "from", j, "ipBlock"),
                        f"ipBlock {ipb.get('cidr')} admits every source address.",
                    )
                ns_sel, pod_sel = peer.get("namespaceSelector"), peer.get("podSelector")
                if ns_sel == {} and pod_sel in (None, {}):
                    yield r.finding(
                        d,
                        ("spec", "ingress", i, "from", j, "namespaceSelector"),
                        "namespaceSelector: {} without a podSelector admits every pod in every namespace.",
                    )


@rule(
    "KN-N008",
    "Service uses externalIPs",
    Stage.AUDIT,
    "network",
    Severity.HIGH,
    "Remove spec.externalIPs and publish the Service through a LoadBalancer Service, a Route or an Ingress; enable "
    "the DenyServiceExternalIPs admission controller on the API server (on a managed platform, ask the provider).",
    "CVE-2020-8554 (every Kubernetes version; the Kubernetes CVE feed says there is no patch, the flaw is in the "
    "design): anyone who can create or update a Service can set externalIPs to any address and so intercept "
    "cluster traffic meant for that address (man in the middle). The Kubernetes docs describe the feature as very "
    "powerful (it allows network traffic interception), say most users do not need it, and recommend the "
    "DenyServiceExternalIPs admission controller, which rejects all net-new use of the field.",
    ("k8s-cve-2020-8554", "k8s-admission-deny-external-ips"),
)
def _n008(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Service"):
        ips = get_path(d.data, ("spec", "externalIPs"))
        if isinstance(ips, list) and ips:
            yield r.finding(
                d,
                ("spec", "externalIPs"),
                f"Service declares externalIPs {[str(x) for x in ips]}: CVE-2020-8554 (every version, no patch) lets "
                "anyone who can create a Service intercept traffic to those addresses from inside the cluster. "
                "Remove externalIPs and enable the DenyServiceExternalIPs admission controller.",
            )


def _annotation_cves(short: str) -> str:
    return "; ".join(f"{cve} ({what})" for cve, what in INGRESS_NGINX_ANNOTATION_CVES.get(short, ()))


@rule(
    "KN-N009",
    "Ingress uses a risky ingress-nginx annotation",
    Stage.AUDIT,
    "network",
    Severity.HIGH,
    "Remove the annotation (move the behaviour into the application or the controller's own configuration); if it "
    "must stay, run a fixed controller release with --enable-annotation-validation, keep allow-snippet-annotations "
    "false and annotations-risk-level at High or below in the controller ConfigMap, and plan the move to a Gateway "
    "API implementation, since ingress-nginx is retired.",
    "ingress-nginx turns some annotation values into nginx configuration. Its annotation risk list rates the five "
    "snippet annotations Critical (raw configuration) and ten more High; these annotations carried the published "
    "injection CVEs: CVE-2021-25742 (snippets read every Secret in the cluster), CVE-2021-25746 (directive "
    "injection through annotation values), CVE-2023-5043 and CVE-2023-5044 (configuration-snippet, "
    "permanent-redirect), CVE-2025-24514, CVE-2025-1097 and CVE-2025-1098 (auth-url, auth-tls-match-cn, "
    "mirror-target and mirror-host), CVE-2025-15566 (auth-proxy-set-headers), CVE-2026-1580 (auth-method), "
    "CVE-2026-24513 (auth-url) and CVE-2026-3288 (rewrite-target). Through the snippets, CVE-2021-25742 obtained "
    "all Secrets in the cluster from an Ingress alone.",
    (
        "ingress-nginx-annotations-risk",
        "k8s-cve-2021-25742",
        "k8s-cve-2021-25746",
        "k8s-cve-2023-5043",
        "k8s-cve-2023-5044",
        "k8s-cve-2025-24514",
        "k8s-cve-2025-1097",
        "k8s-cve-2025-1098",
        "k8s-cve-2025-15566",
        "k8s-cve-2026-1580",
        "k8s-cve-2026-24513",
        "k8s-cve-2026-3288",
        "ingress-nginx-retired",
    ),
)
def _n009(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Ingress"):
        ann = get_path(d.data, ("metadata", "annotations"))
        if not isinstance(ann, dict):
            continue
        for key in sorted(str(k) for k in ann):
            if not key.startswith(INGRESS_NGINX_ANNOTATION_PREFIX):
                continue
            short = key[len(INGRESS_NGINX_ANNOTATION_PREFIX) :]
            if short not in INGRESS_NGINX_RISKY_ANNOTATIONS:
                continue
            cves = _annotation_cves(short)
            path = ("metadata", "annotations", key)
            if short in INGRESS_NGINX_CRITICAL_ANNOTATIONS:
                yield r.finding(
                    d,
                    path,
                    f"Annotation {key} is a snippet, rated Critical risk by ingress-nginx because it injects raw nginx "
                    f"configuration into the controller; {cves}. Remove it and keep allow-snippet-annotations "
                    '"false" in the controller ConfigMap.',
                )
            elif short in INGRESS_NGINX_HIGH_ANNOTATIONS:
                detail = cves or "CVE-2021-25746 (directive injection through annotation values, fixed in v1.2.0)"
                yield r.finding(
                    d,
                    path,
                    f"Annotation {key} is rated High risk by ingress-nginx (its value reaches the nginx "
                    f"configuration); {detail}. Remove it or run a fixed controller with "
                    "--enable-annotation-validation.",
                    severity=Severity.MEDIUM,
                )
            else:
                yield r.finding(
                    d,
                    path,
                    f"Annotation {key} carried a published injection vulnerability: {cves}. Remove it or run a fixed "
                    "controller with --enable-annotation-validation.",
                    severity=Severity.MEDIUM,
                )


@rule(
    "KN-N010",
    "ingress-nginx ConfigMap widens what an Ingress may ask of the controller",
    Stage.AUDIT,
    "network",
    Severity.HIGH,
    'Set allow-snippet-annotations: "false" (the default), leave annotations-risk-level at High (the default) and '
    'strict-validate-path-type: "true" (the default) in the ingress-nginx controller ConfigMap, or remove the keys.',
    "The controller ConfigMap decides which annotations an Ingress may use. allow-snippet-annotations: true re-enables "
    "the snippet annotations through which CVE-2021-25742 read every Secret in the cluster (the feed's fix is to set "
    "it to false); annotations-risk-level: Critical accepts the Critical-risk annotations, which the default High "
    "refuses; strict-validate-path-type: false drops the path validation added for CVE-2022-4886.",
    (
        "ingress-nginx-configmap",
        "k8s-cve-2021-25742",
        "k8s-cve-2023-5043",
        "k8s-cve-2022-4886",
        "ingress-nginx-annotations-risk",
    ),
)
def _n010(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("ConfigMap"):
        data = d.data.get("data") if isinstance(d.data, dict) else None
        if not isinstance(data, dict):
            continue
        for key, (unsafe, default, allows) in INGRESS_NGINX_CONFIGMAP_KEYS.items():
            value = data.get(key)
            if value is None or str(value).strip().lower() != unsafe:
                continue
            cve = {
                "allow-snippet-annotations": "CVE-2021-25742 (snippets read every Secret in the cluster)",
                "annotations-risk-level": "CVE-2021-25742, CVE-2023-5043 (snippet injection)",
                "strict-validate-path-type": "CVE-2022-4886 (path sanitization bypass)",
            }[key]
            yield r.finding(
                d,
                ("data", key),
                f"ConfigMap sets {key}: {str(value).strip()!r} (default {default}), which lets every Ingress use "
                f"{allows}; {cve}. Set it back to the default.",
                severity=Severity.HIGH if key != "strict-validate-path-type" else Severity.MEDIUM,
            )


def ingress_targets_nginx(d: Document) -> bool:
    """The Ingress names ingress-nginx: class 'nginx' (field or annotation) or an nginx.ingress.kubernetes.io/ key."""
    ann = get_path(d.data, ("metadata", "annotations"))
    ann = ann if isinstance(ann, dict) else {}
    spec = get_path(d.data, ("spec",))
    cls = spec.get("ingressClassName") if isinstance(spec, dict) else None
    return (
        (cls is not None and str(cls).strip() == INGRESS_NGINX_CLASS)
        or str(ann.get("kubernetes.io/ingress.class", "")).strip() == INGRESS_NGINX_CLASS
        or any(str(k).startswith(INGRESS_NGINX_ANNOTATION_PREFIX) for k in ann)
    )


def ingress_names_no_class(d: Document) -> bool:
    ann = get_path(d.data, ("metadata", "annotations"))
    spec = get_path(d.data, ("spec",))
    return not (isinstance(spec, dict) and "ingressClassName" in spec) and not (
        isinstance(ann, dict) and "kubernetes.io/ingress.class" in ann
    )


@rule(
    "KN-N011",
    "Ingress path type ImplementationSpecific on ingress-nginx",
    Stage.AUDIT,
    "network",
    Severity.HIGH,
    "Use pathType Prefix or Exact (ingress-nginx validates those paths when strict-validate-path-type is true, the "
    "default), and run ingress-nginx v1.13.7, v1.14.3 or later; a regular-expression path (use-regex) can only be "
    "ImplementationSpecific, so upgrade before keeping one. Plan the move to a Gateway API implementation.",
    "CVE-2026-24512 (ingress-nginx before v1.13.7 and v1.14.3): a rules.http.paths.path value injected nginx "
    "configuration into the controller, which can read every Secret in the cluster. Before upgrading, the advisory's "
    "mitigation is a validating admission controller that rejects Ingress resources with the ImplementationSpecific "
    "path type, the one path type whose paths ingress-nginx does not validate. An Ingress that names no class is "
    "served by the cluster's default IngressClass, which may be ingress-nginx (not on OpenShift, whose router serves "
    "it).",
    ("k8s-cve-2026-24512", "ingress-nginx-configmap", "ingress-nginx-retired"),
)
def _n011(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("Ingress"):
        if ingress_targets_nginx(d):
            sev, who = Severity.HIGH, "ingress-nginx serves this Ingress"
        elif ingress_names_no_class(d) and not ctx.is_openshift:
            sev = Severity.LOW
            who = (
                "the Ingress names no class, so the cluster's default IngressClass serves it (if that is ingress-nginx)"
            )
        else:
            continue
        for i, rule_ in enumerate(get_path(d.data, ("spec", "rules")) or []):
            paths = get_path(rule_, ("http", "paths")) if isinstance(rule_, dict) else None
            for j, p in enumerate(paths if isinstance(paths, list) else []):
                if isinstance(p, dict) and p.get("pathType") == "ImplementationSpecific":
                    yield r.finding(
                        d,
                        ("spec", "rules", i, "http", "paths", j, "pathType"),
                        f"Path {p.get('path', '')!r} has pathType ImplementationSpecific and {who}: CVE-2026-24512 "
                        "(fixed in v1.13.7 and v1.14.3) injected nginx configuration through such paths, and the "
                        "advisory's mitigation is to reject the ImplementationSpecific path type at admission. Use "
                        "Prefix or Exact.",
                        severity=sev,
                    )


def _selects_something(selector: dict[str, Any]) -> bool:
    return bool(selector.get("matchLabels") or selector.get("matchExpressions"))


@rule(
    "KN-N012",
    "NetworkPolicy selects no pod in this bundle",
    Stage.AUDIT,
    "network",
    Severity.MEDIUM,
    "Make spec.podSelector match the pod template labels of the workloads the policy is for (or use podSelector: {} "
    "for every pod in the namespace).",
    "A NetworkPolicy applies only to the pods its podSelector selects. One that selects none of the namespace's pods "
    "(often a label typo) protects nothing, while the namespace still looks covered (KN-N001 passes): the pods it "
    "was written for accept traffic from every pod.",
    ("k8s-networkpolicy",),
)
def _n012(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    by_ns: dict[str, list[dict[str, str]]] = {}
    for d, pt in ctx.workloads():
        by_ns.setdefault(ctx.ns(d), []).append(pt.labels())
    for d in ctx.by_kind("NetworkPolicy"):
        sel = get_path(d.data, ("spec", "podSelector"))
        pods = by_ns.get(ctx.ns(d))
        if not isinstance(sel, dict) or not _selects_something(sel) or not pods:
            continue
        if not any(selector_matches(sel, labels) for labels in pods):
            yield r.finding(
                d,
                ("spec", "podSelector"),
                f"podSelector {sel.get('matchLabels') or sel} selects none of the {len(pods)} pod template(s) in "
                f"namespace {ctx.ns(d)}: this policy protects nothing.",
            )


# =====================================================================================================
# AUDIT - storage
# =====================================================================================================


def _storage_classes(ctx: AuditContext) -> dict[str, dict[str, Any]]:
    return {d.name: d.data for d in ctx.by_kind("StorageClass") if isinstance(d.data, dict)}


def _provisioner_for(ctx: AuditContext, sc_name: str | None) -> str | None:
    if sc_name is None:
        return None
    local = _storage_classes(ctx).get(sc_name)
    if local and local.get("provisioner"):
        return str(local["provisioner"])
    return KNOWN_STORAGE_CLASSES.get(sc_name)


def _pvc_like(ctx: AuditContext) -> Iterator[tuple[Document, PathT, dict[str, Any]]]:
    for d in ctx.by_kind("PersistentVolumeClaim"):
        if isinstance(d.data.get("spec"), dict):
            yield d, ("spec",), d.data["spec"]
    for d in ctx.by_kind("StatefulSet"):
        for i, vct in enumerate(get_path(d.data, ("spec", "volumeClaimTemplates")) or []):
            if isinstance(vct, dict) and isinstance(vct.get("spec"), dict):
                yield d, ("spec", "volumeClaimTemplates", i, "spec"), vct["spec"]


@rule(
    "KN-ST001",
    "ReadWriteMany requested from a ReadWriteOnce-only StorageClass",
    Stage.AUDIT,
    "storage",
    Severity.HIGH,
    "Use a shared-filesystem class: efs-sc (AWS EFS CSI) on ROSA/EKS, ocs-storagecluster-cephfs (ODF) or NFS on "
    "OpenShift on-prem, azurefile-csi on Azure. gp3-csi/gp2-csi (EBS) are block volumes and only support "
    "ReadWriteOnce.",
    "The provisioner cannot satisfy RWX, so the PVC stays Pending (ProvisioningFailed).",
    ("k8s-pv-access-modes", "aws-ebs-csi", "aws-efs-csi", "odf-access-modes"),
)
def _st001(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, path, spec in _pvc_like(ctx):
        modes = spec.get("accessModes") or []
        if "ReadWriteMany" not in modes:
            continue
        sc = spec.get("storageClassName")
        prov = _provisioner_for(ctx, sc)
        if prov is None:
            if sc is None:
                if ctx.is_rosa:
                    yield r.finding(
                        d,
                        (*path, "accessModes"),
                        "RWX without storageClassName: the ROSA default "
                        "class (gp3-csi, EBS) is RWO-only, so this PVC will not bind.",
                    )
                elif ctx.is_openshift:
                    yield r.finding(
                        d,
                        (*path, "accessModes"),
                        "RWX without storageClassName: verify the cluster "
                        "default StorageClass supports ReadWriteMany (most block classes do not).",
                        severity=Severity.MEDIUM,
                    )
            elif sc != "":  # "" = static binding to a pre-created PV, no provisioner involved
                yield r.finding(
                    d,
                    (*path, "storageClassName"),
                    f"StorageClass '{sc}' is neither defined in this bundle nor a known platform class: cannot verify "
                    "that its provisioner supports ReadWriteMany. Include the StorageClass or use a known RWX class.",
                    severity=Severity.MEDIUM,
                )
            continue
        p = PROVISIONERS.get(prov)
        if p is None:
            yield r.finding(
                d,
                (*path, "storageClassName"),
                f"Provisioner '{prov}' of StorageClass '{sc}' is not in kube-noob's catalog: verify it supports "
                "ReadWriteMany before relying on it.",
                severity=Severity.MEDIUM,
            )
            continue
        block = spec.get("volumeMode") == "Block"
        if not (p.rwx_filesystem or (block and p.rwx_block)):
            hint = " (RWX is only possible with volumeMode: Block)" if p.rwx_block else ""
            yield r.finding(
                d,
                (*path, "storageClassName"),
                f"StorageClass '{sc}' ({prov}: {p.description}) cannot provide ReadWriteMany{hint}.",
            )


@rule(
    "KN-ST002",
    "ReadWriteOnce volume shared by a rolling Deployment",
    Stage.AUDIT,
    "storage",
    Severity.HIGH,
    "Use a StatefulSet with volumeClaimTemplates, strategy: Recreate with replicas: 1, or a RWX class if the app "
    "supports concurrent writers.",
    "A RWO volume attaches to one node. Extra replicas or surge pods scheduled elsewhere hang in "
    "ContainerCreating with 'Multi-Attach error for volume'.",
    ("k8s-pv-access-modes",),
)
def _st002(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    pvcs = {(ctx.ns(d), d.name): d.data.get("spec", {}) for d in ctx.by_kind("PersistentVolumeClaim")}
    for d in ctx.by_kind("Deployment", "DeploymentConfig"):
        pt = pod_template(d)
        if pt is None:
            continue
        for i, v in enumerate(pt.spec.get("volumes") or []):
            claim = get_path(v, ("persistentVolumeClaim", "claimName")) if isinstance(v, dict) else None
            if not claim:
                continue
            spec = pvcs.get((ctx.ns(d), str(claim)))
            modes = (spec or {}).get("accessModes") or []
            if spec is None or "ReadWriteMany" in modes or "ReadOnlyMany" in modes:
                continue
            reps = replicas(d) or 1
            strategy = get_path(d.data, ("spec", "strategy", "type")) or "RollingUpdate"
            if reps > 1:
                yield r.finding(
                    d,
                    (*pt.path, "volumes", i),
                    f"{reps} replicas share RWO PVC '{claim}'; pods on other nodes cannot attach it.",
                )
            elif strategy in {"RollingUpdate", "Rolling"}:
                yield r.finding(
                    d,
                    ("spec", "strategy"),
                    f"RollingUpdate with RWO PVC '{claim}': the surge pod "
                    "can deadlock on Multi-Attach. Use strategy: Recreate.",
                    severity=Severity.MEDIUM,
                )


@rule(
    "KN-ST003",
    "Zonal storage with Immediate volume binding",
    Stage.AUDIT,
    "storage",
    Severity.MEDIUM,
    "Set volumeBindingMode: WaitForFirstConsumer so the volume is created in the zone the pod is scheduled to.",
    "Immediate binding may create the volume in a zone where the pod cannot run, leaving it Pending.",
    ("k8s-storageclass-binding",),
)
def _st003(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("StorageClass"):
        p = PROVISIONERS.get(str(d.data.get("provisioner")))
        mode = d.data.get("volumeBindingMode", "Immediate")
        if p and p.zonal and mode == "Immediate":
            yield r.finding(d, ("volumeBindingMode",), f"{p.name} is zonal but volumeBindingMode is Immediate.")


@rule(
    "KN-ST004",
    "EFS StorageClass is missing required parameters",
    Stage.AUDIT,
    "storage",
    Severity.HIGH,
    "Set parameters.provisioningMode: efs-ap and parameters.fileSystemId: fs-xxxxxxxx (plus directoryPerms).",
    "Dynamic provisioning with the AWS EFS CSI driver uses access points and needs the file system id.",
    ("aws-efs-csi", "rosa-efs"),
)
def _st004(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("StorageClass"):
        if d.data.get("provisioner") != "efs.csi.aws.com":
            continue
        params = d.data.get("parameters") or {}
        missing = [k for k in ("provisioningMode", "fileSystemId") if not params.get(k)]
        if missing:
            yield r.finding(d, ("parameters",), f"Missing parameter(s): {', '.join(missing)}.")


@rule(
    "KN-ST005",
    "PVC has no storage request",
    Stage.VALIDATE,
    "storage",
    Severity.HIGH,
    "Set spec.resources.requests.storage (e.g. 10Gi).",
    "The API server rejects PersistentVolumeClaims without a storage request.",
    ("k8s-pv-access-modes",),
)
def _st005(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, path, spec in _pvc_like(ctx):
        if not get_path(spec, ("resources", "requests", "storage")):
            yield r.finding(d, (*path, "resources"), "spec.resources.requests.storage is missing.")


# A '..' path segment ('/', '\' and '#', the NFS and SMB volumeHandle separator, delimit segments). RE2 too.
PATH_TRAVERSAL = r"(^|[/\\#])\.\.([/\\#]|$)"
_PATH_TRAVERSAL = re.compile(PATH_TRAVERSAL[:-2] + r"\Z)")
# CSI drivers whose subDir traversal deleted directories outside the share: driver -> (CVE, project, fixed release).
CSI_SUBDIR_TRAVERSAL: dict[str, tuple[str, str, str]] = {
    "nfs.csi.k8s.io": ("CVE-2026-3864", "CSI Driver for NFS", "v4.13.1"),
    "smb.csi.k8s.io": ("CVE-2026-3865", "CSI Driver for SMB", "v1.20.1"),
}


@rule(
    "KN-ST006",
    "PersistentVolume path carries command or traversal characters",
    Stage.AUDIT,
    "storage",
    Severity.HIGH,
    "Use a plain absolute local path, and a volumeHandle and subDir without '..' segments; run Windows nodes with "
    "kubelet v1.25.16, v1.26.11, v1.27.8, v1.28.4 or later, csi-driver-nfs v4.13.1 or later and csi-driver-smb "
    "v1.20.1 or later; let only cluster administrators create PersistentVolumes.",
    "CVE-2023-5528 (CVSS 7.2; kubelet from v1.8.0, fixed in v1.25.16, v1.26.11, v1.27.8 and v1.28.4): on Windows "
    "nodes the in-tree storage plugin ran a local PersistentVolume path as part of a command, so a user who could "
    "create pods and PersistentVolumes got admin rights on the node; the feed names PersistentVolume create events "
    "with local path fields containing special characters as the sign of exploitation. CVE-2026-3864 (csi-driver-nfs "
    "before v4.13.1) and CVE-2026-3865 (csi-driver-smb before v1.20.1): a '../' in the subDir of a volume identifier "
    "made the driver delete directories outside the share; the advisories say to look for traversal sequences in the "
    "volumeHandle of PersistentVolumes using these drivers.",
    ("k8s-cve-2023-5528", "k8s-cve-2026-3864", "k8s-cve-2026-3865"),
)
def _st006(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind("PersistentVolume"):
        local = get_path(d.data, ("spec", "local", "path"))
        if isinstance(local, str) and _COMMAND_META.search(local):
            yield r.finding(
                d,
                ("spec", "local", "path"),
                f"Local path {local!r} carries {_meta_chars(local)}: the CVE-2023-5528 pattern, where kubelet on "
                "Windows nodes (before v1.25.16, v1.26.11, v1.27.8 and v1.28.4) ran the path as part of a command "
                "with admin rights on the node. Use a plain path.",
            )
        csi = get_path(d.data, ("spec", "csi"))
        hit = CSI_SUBDIR_TRAVERSAL.get(str(csi.get("driver"))) if isinstance(csi, dict) else None
        if hit is None or not isinstance(csi, dict):
            continue
        cve, project, fixed = hit
        attrs = csi.get("volumeAttributes")
        fields: list[tuple[PathT, object]] = [(("spec", "csi", "volumeHandle"), csi.get("volumeHandle"))]
        if isinstance(attrs, dict):
            fields.append((("spec", "csi", "volumeAttributes", "subDir"), attrs.get("subDir")))
        for path, value in fields:
            if isinstance(value, str) and _PATH_TRAVERSAL.search(value):
                yield r.finding(
                    d,
                    path,
                    f"{path[-1]} {value!r} of the {csi.get('driver')} volume has a '..' segment: {cve} ({project} "
                    f"before {fixed}) deleted directories outside the share through such a subDir. Remove the "
                    "traversal and upgrade the driver.",
                )


# =====================================================================================================
# CALIBRATE - reliability, HA, efficiency
# =====================================================================================================


def _long_running_containers(ctx: AuditContext) -> Iterator[tuple[Document, PodTemplate, ContainerRef]]:
    for d, pt in ctx.workloads():
        if d.kind in LONG_RUNNING_KINDS:
            for c in containers(pt, include_init=False):
                yield d, pt, c


@rule(
    "KN-C001",
    "No readiness probe",
    Stage.CALIBRATE,
    "reliability",
    Severity.MEDIUM,
    "Add a readinessProbe (httpGet on a /ready endpoint, or tcpSocket) so traffic only reaches ready pods.",
    "Without readiness, Services route to pods that are still starting or degraded, and rollouts cannot detect "
    "bad versions.",
    ("k8s-probes",),
)
def _c001(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _long_running_containers(ctx):
        if not c.container.get("readinessProbe"):
            yield r.finding(d, c.path, f"Container '{c.name}' has no readinessProbe.")


@rule(
    "KN-C002",
    "No liveness probe",
    Stage.CALIBRATE,
    "reliability",
    Severity.LOW,
    "Add a livenessProbe that checks the process itself (not its dependencies); use a startupProbe for slow starts.",
    "Deadlocked processes are never restarted without liveness.",
    ("k8s-probes",),
)
def _c002(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _long_running_containers(ctx):
        if not c.container.get("livenessProbe"):
            yield r.finding(d, c.path, f"Container '{c.name}' has no livenessProbe.")


@rule(
    "KN-C003",
    "Liveness probe is aggressive",
    Stage.CALIBRATE,
    "reliability",
    Severity.MEDIUM,
    "Use periodSeconds >= 10, failureThreshold >= 3 and timeoutSeconds < periodSeconds; add a startupProbe "
    "for slow boots.",
    "Aggressive liveness turns a slow dependency or GC pause into a restart storm (red-team: cascading failure).",
    ("k8s-probes",),
)
def _c003(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _long_running_containers(ctx):
        p = c.container.get("livenessProbe")
        if not isinstance(p, dict):
            continue
        period, fail = p.get("periodSeconds", 10), p.get("failureThreshold", 3)
        timeout = p.get("timeoutSeconds", 1)
        issues = []
        if isinstance(fail, int) and fail < 2:
            issues.append(f"failureThreshold={fail}")
        if isinstance(period, int) and period < 5:
            issues.append(f"periodSeconds={period}")
        if isinstance(timeout, int) and isinstance(period, int) and timeout >= period:
            issues.append(f"timeoutSeconds({timeout}) >= periodSeconds({period})")
        if issues:
            yield r.finding(d, (*c.path, "livenessProbe"), f"Container '{c.name}': {', '.join(issues)}.")


@rule(
    "KN-C004",
    "Missing CPU/memory requests",
    Stage.CALIBRATE,
    "resources",
    Severity.MEDIUM,
    "Set resources.requests.cpu and resources.requests.memory from observed usage (p95).",
    "Without requests the scheduler overcommits nodes, pods get BestEffort QoS and are evicted first; HPA cannot "
    "compute utilization.",
    ("k8s-resources",),
    ("No CPU request or memory limit specified",),
)
def _c004(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _resource_containers(ctx):
        req = get_path(c.container, ("resources", "requests")) or {}
        missing = [k for k in ("cpu", "memory") if k not in req]
        if missing:
            yield r.finding(d, (*c.path, "resources"), f"Container '{c.name}' has no {'/'.join(missing)} request.")


@rule(
    "KN-C005",
    "Missing memory limit",
    Stage.CALIBRATE,
    "resources",
    Severity.MEDIUM,
    "Set resources.limits.memory (typically 1-2x the request).",
    "An unbounded container can exhaust node memory and trigger node-level OOM kills of other workloads.",
    ("k8s-resources",),
    ("No CPU request or memory limit specified",),
)
def _c005(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _resource_containers(ctx):
        if not get_path(c.container, ("resources", "limits", "memory")):
            yield r.finding(d, (*c.path, "resources"), f"Container '{c.name}' has no memory limit.")


@rule(
    "KN-C006",
    "Request exceeds limit",
    Stage.VALIDATE,
    "resources",
    Severity.HIGH,
    "Make every request <= its limit.",
    "The API server rejects containers whose request is greater than the limit.",
    ("k8s-resources",),
)
def _c006(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, _pt, c in _resource_containers(ctx):
        req = get_path(c.container, ("resources", "requests")) or {}
        lim = get_path(c.container, ("resources", "limits")) or {}
        for k in ("cpu", "memory", "ephemeral-storage"):
            if k in req and k in lim:
                try:
                    if parse_quantity(req[k]) > parse_quantity(lim[k]):
                        yield r.finding(
                            d,
                            (*c.path, "resources", "requests", k),
                            f"Container '{c.name}' {k} request {req[k]} > limit {lim[k]}.",
                        )
                except ValueError as exc:
                    yield r.finding(d, (*c.path, "resources"), f"Container '{c.name}': {exc}.")


@rule(
    "KN-C007",
    "Single replica",
    Stage.CALIBRATE,
    "availability",
    Severity.MEDIUM,
    "Run at least 2 replicas (3 across zones for production) with a PodDisruptionBudget.",
    "One replica means downtime on every node drain, upgrade or node failure.",
    ("k8s-pdb",),
)
def _c007(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d in ctx.by_kind(*REPLICATED_KINDS):
        reps = replicas(d)
        if reps is not None and reps < 2 and not _has_hpa(ctx, d):
            yield r.finding(d, ("spec", "replicas"), f"{d.kind} runs {reps} replica(s).")


def _has_hpa(ctx: AuditContext, d: Document) -> bool:
    for h in ctx.by_kind("HorizontalPodAutoscaler"):
        ref = get_path(h.data, ("spec", "scaleTargetRef")) or {}
        if ref.get("name") == d.name and ref.get("kind") == d.kind and ctx.ns(h) == ctx.ns(d):
            return True
    return False


def _pdbs_for(ctx: AuditContext, d: Document, labels: dict[str, str]) -> list[Document]:
    return [
        p
        for p in ctx.by_kind("PodDisruptionBudget")
        if ctx.ns(p) == ctx.ns(d) and selector_matches(get_path(p.data, ("spec", "selector")), labels)
    ]


@rule(
    "KN-C008",
    "No PodDisruptionBudget",
    Stage.CALIBRATE,
    "availability",
    Severity.LOW,
    "Add a PodDisruptionBudget with maxUnavailable: 1 for replicated workloads.",
    "Without a PDB a node drain may evict all replicas at once.",
    ("k8s-pdb",),
)
def _c008(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        if d.kind in REPLICATED_KINDS and (replicas(d) or 1) >= 2 and not _pdbs_for(ctx, d, pt.labels()):
            yield r.finding(d, ("spec",), "No PodDisruptionBudget selects this workload.")


@rule(
    "KN-C009",
    "PodDisruptionBudget blocks all voluntary evictions",
    Stage.CALIBRATE,
    "availability",
    Severity.HIGH,
    "Use maxUnavailable: 1 (or minAvailable < replicas).",
    "A PDB that allows zero disruptions blocks node drains, so cluster upgrades (including managed ROSA "
    "upgrades) stall on this node.",
    ("k8s-pdb",),
)
def _c009(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        if d.kind not in REPLICATED_KINDS:
            continue
        reps = replicas(d) or 1
        for p in _pdbs_for(ctx, d, pt.labels()):
            spec = p.data.get("spec") or {}
            if pdb_allows_no_disruption(spec, reps):
                yield r.finding(p, ("spec",), f"{p.ref()} allows no disruptions for {d.ref()} ({reps} replicas).")


@rule(
    "KN-C010",
    "Replicas not spread across zones/nodes",
    Stage.CALIBRATE,
    "availability",
    Severity.LOW,
    "Add topologySpreadConstraints on topology.kubernetes.io/zone (and kubernetes.io/hostname) or pod anti-affinity.",
    "Replicas may all land on one node or zone; a single failure takes the app down.",
    ("k8s-topology-spread",),
)
def _c010(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        if d.kind not in REPLICATED_KINDS or (replicas(d) or 1) < 2:
            continue
        if pt.spec.get("topologySpreadConstraints") or get_path(pt.spec, ("affinity", "podAntiAffinity")):
            continue
        sev = Severity.MEDIUM if ctx.is_rosa else Severity.LOW
        yield r.finding(d, pt.path, "No topologySpreadConstraints or podAntiAffinity.", severity=sev)


@rule(
    "KN-C011",
    "terminationGracePeriodSeconds is 0",
    Stage.CALIBRATE,
    "reliability",
    Severity.LOW,
    "Allow time for graceful shutdown (default 30s) and handle SIGTERM.",
    "A zero grace period kills in-flight requests and can corrupt state.",
    ("k8s-probes",),
)
def _c011(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for d, pt in ctx.workloads():
        if pt.spec.get("terminationGracePeriodSeconds") == 0:
            yield r.finding(d, (*pt.path, "terminationGracePeriodSeconds"), "Grace period is 0.")


@rule(
    "KN-C012",
    "HPA cannot compute CPU utilization",
    Stage.CALIBRATE,
    "resources",
    Severity.MEDIUM,
    "Set CPU requests on every container of the target workload.",
    "Utilization-based HPA divides usage by the request; missing requests leave the HPA at <unknown>.",
    ("k8s-resources",),
)
def _c012(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for h in ctx.by_kind("HorizontalPodAutoscaler"):
        ref = get_path(h.data, ("spec", "scaleTargetRef")) or {}
        metrics = get_path(h.data, ("spec", "metrics")) or []
        uses_cpu_util = any(
            get_path(m, ("resource", "name")) == "cpu" and get_path(m, ("resource", "target", "type")) == "Utilization"
            for m in metrics
            if isinstance(m, dict)
        )
        if not uses_cpu_util:
            continue
        for d, pt in ctx.workloads():
            is_target = d.name == ref.get("name") and d.kind == ref.get("kind") and ctx.ns(d) == ctx.ns(h)
            if is_target and any(
                not get_path(c.container, ("resources", "requests", "cpu")) for c in containers(pt, include_init=False)
            ):
                yield r.finding(h, ("spec", "metrics"), f"Target {d.ref()} has containers without CPU requests.")


def _pull_secret_names(spec: object) -> list[str]:
    refs = get_path(spec, ("imagePullSecrets",)) if isinstance(spec, dict) else None
    return [str(x["name"]) for x in refs or [] if isinstance(x, dict) and x.get("name")]


@rule(
    "KN-C013",
    "Pull secret exists only in another namespace",
    Stage.VALIDATE,
    "reliability",
    Severity.HIGH,
    "Create (or sync) the pull secret in the workload's namespace and link it to its ServiceAccount; on OpenShift put "
    "a registry every project uses in the global pull secret, and grant system:image-puller for another project's "
    "internal registry.",
    "imagePullSecrets name Secrets in the pod's own namespace (LocalObjectReference): kubelet never looks in another "
    "namespace, reports FailedToRetrieveImagePullSecret and the pull fails with ImagePullBackOff.",
    ("k8s-images",),
)
def _c013(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    secrets: dict[str, set[str]] = {}
    for s in ctx.by_kind("Secret"):
        if s.name:
            secrets.setdefault(s.name, set()).add(ctx.ns(s))
    if not secrets:
        return  # the bundle carries no Secrets: nothing to compare with

    def check(doc: Document, path: PathT, names: list[str]) -> Iterator[Finding]:
        ns = ctx.ns(doc)
        for i, name in enumerate(names):
            elsewhere = secrets.get(name, set()) - {ns}
            if elsewhere and ns not in secrets.get(name, set()):
                yield r.finding(
                    doc,
                    (*path, "imagePullSecrets", i),
                    f"Pull secret '{name}' is defined in namespace {', '.join(sorted(elsewhere))}, not in {ns}, "
                    f"where kubelet looks for it.",
                )

    for d, pt in ctx.workloads():
        yield from check(d, pt.path, _pull_secret_names(pt.spec))
    for sa in ctx.by_kind("ServiceAccount"):
        yield from check(sa, (), _pull_secret_names(sa.data))


@rule(
    "KN-C014",
    "Workload scaled by an HPA also sets spec.replicas",
    Stage.CALIBRATE,
    "availability",
    Severity.MEDIUM,
    "Remove spec.replicas from the manifest of a workload a HorizontalPodAutoscaler scales (in a Helm chart: "
    "{{- if not .Values.autoscaling.enabled }} replicas: ... {{- end }}); set the floor with the HPA's minReplicas.",
    "The Kubernetes docs recommend removing spec.replicas when an HPA is enabled: otherwise every kubectl apply (or "
    "GitOps sync) of the manifest scales the workload back to that number, which may not be desired and causes "
    "thrashing or flapping while the HPA is active, for example down to 2 replicas in the middle of a traffic peak. "
    "A target whose replica count is 0 deactivates an HPA whose minReplicas is above 0.",
    ("k8s-hpa-replicas",),
)
def _c014(ctx: AuditContext, r: Rule) -> Iterator[Finding]:
    for h in ctx.by_kind("HorizontalPodAutoscaler"):
        ref = get_path(h.data, ("spec", "scaleTargetRef"))
        if not isinstance(ref, dict):
            continue
        for d in ctx.by_kind(*REPLICATED_KINDS):
            if d.name != ref.get("name") or d.kind != ref.get("kind") or ctx.ns(d) != ctx.ns(h):
                continue
            spec = d.data.get("spec") if isinstance(d.data, dict) else None
            if not isinstance(spec, dict) or "replicas" not in spec:
                continue
            count = spec["replicas"]
            low = get_path(h.data, ("spec", "minReplicas"))
            low = low if isinstance(low, int) else 1
            if count == 0 and low > 0:
                yield r.finding(
                    d,
                    ("spec", "replicas"),
                    f"{d.ref()} sets replicas: 0 and {h.ref()} (minReplicas {low}) scales it: a target at 0 replicas "
                    "deactivates the HPA until someone scales it by hand. Remove spec.replicas.",
                    severity=Severity.HIGH,
                )
            else:
                yield r.finding(
                    d,
                    ("spec", "replicas"),
                    f"{d.ref()} sets replicas: {count} and {h.ref()} scales it: every apply or GitOps sync of this "
                    f"manifest resets the count to {count} and fights the HPA. Remove spec.replicas.",
                )


def run_rules(ctx: AuditContext, stages: set[Stage] | None = None) -> list[Finding]:
    findings: list[Finding] = []
    for r in RULES.values():
        if stages is not None and r.stage not in stages:
            continue
        if r.check is not None:
            findings.extend(r.check(ctx, r))
    return findings
